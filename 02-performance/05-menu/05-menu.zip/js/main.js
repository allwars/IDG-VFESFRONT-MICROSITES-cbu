/**
 * Vodafone Reboot Framework: Version 15.3.0. Generation Date: 2020-01-28T15:23:41.261Z
 */

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "../microsites-cbu/02-performance/05-menu/resources/scripts/main.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../microsites-cbu/02-performance/05-menu/resources/scripts/_menu-performance.js":
/*!***************************************************************************************!*\
  !*** ../microsites-cbu/02-performance/05-menu/resources/scripts/_menu-performance.js ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MenuPerformance; });
class MenuPerformance {
  init() {
    console.log("INIT MENU");
    this.menuMobile();
  }

  menuMobile() {
    //Device width and orientation
    var isDesktop = window.innerWidth >= 970;
    var isTablet = window.innerWidth < 970 && window.innerWidth >= 640;
    var isMobile = window.innerWidth < 640; //Main nav container

    var mainNav = document.getElementById("vfms-main-header__main-nav"); //Main menu item.

    var mainNavItems = document.querySelectorAll(".vfms-main-nav-item"); // Main Nav item container

    var mainNavBox = document.querySelectorAll(".vfms-main-nav-container__item");
    var items = document.querySelectorAll('.vfms-main-item__type'); //Secundary nav container

    var secNav = document.querySelectorAll(".vfms-sec-nav"); //Secundary nav items

    var secNavItems = document.querySelectorAll(".vfms-sec-nav-item");
    var openMenu = document.getElementById('vfms-recursive-nav__button');
    openMenu.addEventListener('click', function (event) {
      //change icon shape
      openMenu.classList.toggle("vfms-isOpen"); //Show main nav container. Change display of the element.

      mainNav.classList.toggle("vfms-showMainNav");
    }); //Tablet and Mobile.

    if (isTablet || isMobile) {
      // AL pinchar en el menú de hamburguesa 
      openMenu.addEventListener('click', function (event) {
        // Todas las navegaciones secundarias estarán escondidas
        for (var i = 0; i < secNav.length; i++) {
          secNav[i].style.display = "none";
        } //Los items de la navegación principal no deben estar en rojo al desplegarse el menú


        for (var i = 0; i < mainNavItems.length; i++) {
          mainNavItems[i].classList.remove("vfms-changeIcon");
          mainNavItems[i].classList.remove("vfes-colours--vodafone-red");
          mainNavItems[i].parentElement.classList.remove("vfms-borderColor");
        } //Los items de la navegación principal no deben estar en rojo al desplegarse el menú


        for (var i = 0; i < items.length; i++) {
          items[i].classList.remove("vfes-colours--vodafone-red");
        }
      }); //Funciones correspondientes al evento click de los elementos de la navegación principal.

      mainNavItems.forEach(item => {
        item.addEventListener('click', () => {
          // Todas las navegaciones secundarias tienen que estar escondidas menos la que sigue al que se está pinchando.
          secNav.forEach(item => {
            for (var i = 0; i < secNav.length; i++) {
              secNav[i].style.display = 'none';
            }
          }); // //Elemento de navegación secundaria

          var sec = item.nextElementSibling; //sec.classList.toggle("vfms-showNav");

          sec.style.display = sec.style.display === 'none' ? 'block' : 'none'; //Elemento de navegación secundaria

          var sec = item.nextElementSibling;
          sec.classList.toggle("vfms-showSecNav"); // Los elementos de la navegación secundaria deben de tener el fondo blanco. 

          secNavItems.forEach(item => {
            for (var i = 0; i < secNavItems.length; i++) {
              secNavItems[i].classList.remove("vfes-colours-bg-aluminium");
            }
          }); //El item cambia de color

          var type = item.querySelector(".vfms-main-item__type");
          type.classList.toggle("vfes-colours--vodafone-red");
          item.classList.toggle("vfms-changeIcon");
          item.classList.toggle("vfes-colours--vodafone-red");
          item.parentElement.classList.toggle("vfms-borderColor");
        });
      }); //Secundary Navigation Items Event click change the item background.

      secNavItems.forEach(item => {
        item.addEventListener('click', () => {
          for (var i = 0; i < secNavItems.length; i++) {
            //click in another item remove background color.
            secNavItems[i].classList.remove("vfes-colours-bg-aluminium");
          }

          item.classList.toggle("vfes-colours-bg-aluminium");
        });
      });
    }
  }

}

/***/ }),

/***/ "../microsites-cbu/02-performance/05-menu/resources/scripts/main.js":
/*!**************************************************************************!*\
  !*** ../microsites-cbu/02-performance/05-menu/resources/scripts/main.js ***!
  \**************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tools__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tools */ "../microsites-cbu/02-performance/05-menu/resources/scripts/tools.js");
/* harmony import */ var _menu_performance__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_menu-performance */ "../microsites-cbu/02-performance/05-menu/resources/scripts/_menu-performance.js");


/*
 *   Método que se dispara cuando el ws2r.vX.css
 *   ya se ha cargado y ha pintado la web
 * */

_tools__WEBPACK_IMPORTED_MODULE_0__["default"].onStylesReady = () => {
  console.log("Site visually ready"); // DO SOMETHING
};
/*
 *   Método que se dispara cuando el ws2r.vX.js
 *   ya se ha cargado y está diponible.
 * */


_tools__WEBPACK_IMPORTED_MODULE_0__["default"].onFrameworkReady = () => {
  console.log("Site functionality ready"); // DO SOMETHING

  var miMenu = new _menu_performance__WEBPACK_IMPORTED_MODULE_1__["default"]();
  miMenu.init();
};

/***/ }),

/***/ "../microsites-cbu/02-performance/05-menu/resources/scripts/tools.js":
/*!***************************************************************************!*\
  !*** ../microsites-cbu/02-performance/05-menu/resources/scripts/tools.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/*
 * Microsites tools js:
 * Este fichero es una muestra de utilidades propias para los microsites.
 * Se puede personalizar a tu gusto
 *
 */
const MICROSITE_ID = '#multipestana-v2';
const cssMain = document.querySelector('link[data-microcss]');
const MICROSITE_SELECTION = closest(document.querySelector(MICROSITE_ID), '[data-pathmicrosite]');
const PATH_MICROSITE = MICROSITE_SELECTION ? MICROSITE_SELECTION.dataset.pathmicrosite : '';
let width = document.documentElement.clientWidth;
let isDesktop = width > 969;
let isTablet = width <= 969 && width >= 768;
let isMobile = width < 768 && width > 300;
/*
* Searches for the parent node closest to the element, which complies with the selector
* @param {} el - Description
* @param {} selector - Description
* @param {} stopSelector - Description
* */

function closest(el, selector, stopSelector) {
  let retval = null;

  while (el) {
    if (el.matches(selector)) {
      retval = el;
      break;
    } else if (stopSelector && el.matches(stopSelector)) {
      break;
    }

    el = el.parentElement;
  }

  return retval;
}
/*
* Removes the style attr, once the stylesheet have been loaded
* return undefined
* */


function _internalCSSInit() {
  document.querySelector('.vfes-ms-content').removeAttribute("style");
  ex.cssLoaded = true;
  ex.onStylesReady();
}
/*
* Initializes functionality JS, and advices when JS is loaded.
* return undefined
* */


function _internalJSInit() {
  window.vfes._utils.init(document.querySelector('.vfes-ms-content'));

  ex.onFrameworkReady();
}
/*
* Check if stylesheet CSS is loaded
* @return {boolean}
* */


function isCSSMicroLoaded() {
  const domStyles = document.styleSheets;
  let countCSS = 0;
  [].forEach.call(domStyles, item => {
    const href = item.href || '';

    if (href.indexOf('ws2r') !== -1) {
      console.log('WS2R Loaded');
      countCSS++;
    }

    if (href.indexOf('main') !== -1) {
      console.log('MAIN.CSS Loaded');
      countCSS++;
    }
  });
  return countCSS === 2;
}

function init() {} // DO SOMETHING

/*
* listen event, once have been loaded the files CSS
* */


if (!isCSSMicroLoaded()) {
  cssMain.addEventListener('load', _internalCSSInit);
} else if (isCSSMicroLoaded()) {
  setTimeout(_internalCSSInit, 100);
}
/*
* listen event, once have been loaded the files JS
* */


if (window.vfes) {
  setTimeout(_internalJSInit, 100);
} else {
  document.addEventListener('vfes:frameworkReady', _internalJSInit);
}

const ex = {
  isDesktop,
  isTablet,
  isMobile,
  micrositeId: MICROSITE_ID,
  micrositePath: PATH_MICROSITE,
  init: init,
  cssLoaded: false,
  onStylesReady: () => null,
  onFrameworkReady: () => null
};
/* harmony default export */ __webpack_exports__["default"] = (ex);

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4uL21pY3Jvc2l0ZXMtY2J1LzAyLXBlcmZvcm1hbmNlLzA1LW1lbnUvcmVzb3VyY2VzL3NjcmlwdHMvX21lbnUtcGVyZm9ybWFuY2UuanMiLCJ3ZWJwYWNrOi8vLy4uL21pY3Jvc2l0ZXMtY2J1LzAyLXBlcmZvcm1hbmNlLzA1LW1lbnUvcmVzb3VyY2VzL3NjcmlwdHMvbWFpbi5qcyIsIndlYnBhY2s6Ly8vLi4vbWljcm9zaXRlcy1jYnUvMDItcGVyZm9ybWFuY2UvMDUtbWVudS9yZXNvdXJjZXMvc2NyaXB0cy90b29scy5qcyJdLCJuYW1lcyI6WyJNZW51UGVyZm9ybWFuY2UiLCJpbml0IiwiY29uc29sZSIsImxvZyIsIm1lbnVNb2JpbGUiLCJpc0Rlc2t0b3AiLCJ3aW5kb3ciLCJpbm5lcldpZHRoIiwiaXNUYWJsZXQiLCJpc01vYmlsZSIsIm1haW5OYXYiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwibWFpbk5hdkl0ZW1zIiwicXVlcnlTZWxlY3RvckFsbCIsIm1haW5OYXZCb3giLCJpdGVtcyIsInNlY05hdiIsInNlY05hdkl0ZW1zIiwib3Blbk1lbnUiLCJhZGRFdmVudExpc3RlbmVyIiwiZXZlbnQiLCJjbGFzc0xpc3QiLCJ0b2dnbGUiLCJpIiwibGVuZ3RoIiwic3R5bGUiLCJkaXNwbGF5IiwicmVtb3ZlIiwicGFyZW50RWxlbWVudCIsImZvckVhY2giLCJpdGVtIiwic2VjIiwibmV4dEVsZW1lbnRTaWJsaW5nIiwidHlwZSIsInF1ZXJ5U2VsZWN0b3IiLCJ0b29scyIsIm9uU3R5bGVzUmVhZHkiLCJvbkZyYW1ld29ya1JlYWR5IiwibWlNZW51IiwiTUlDUk9TSVRFX0lEIiwiY3NzTWFpbiIsIk1JQ1JPU0lURV9TRUxFQ1RJT04iLCJjbG9zZXN0IiwiUEFUSF9NSUNST1NJVEUiLCJkYXRhc2V0IiwicGF0aG1pY3Jvc2l0ZSIsIndpZHRoIiwiZG9jdW1lbnRFbGVtZW50IiwiY2xpZW50V2lkdGgiLCJlbCIsInNlbGVjdG9yIiwic3RvcFNlbGVjdG9yIiwicmV0dmFsIiwibWF0Y2hlcyIsIl9pbnRlcm5hbENTU0luaXQiLCJyZW1vdmVBdHRyaWJ1dGUiLCJleCIsImNzc0xvYWRlZCIsIl9pbnRlcm5hbEpTSW5pdCIsInZmZXMiLCJfdXRpbHMiLCJpc0NTU01pY3JvTG9hZGVkIiwiZG9tU3R5bGVzIiwic3R5bGVTaGVldHMiLCJjb3VudENTUyIsImNhbGwiLCJocmVmIiwiaW5kZXhPZiIsInNldFRpbWVvdXQiLCJtaWNyb3NpdGVJZCIsIm1pY3Jvc2l0ZVBhdGgiXSwibWFwcGluZ3MiOiI7QUFBQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGtEQUEwQyxnQ0FBZ0M7QUFDMUU7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxnRUFBd0Qsa0JBQWtCO0FBQzFFO0FBQ0EseURBQWlELGNBQWM7QUFDL0Q7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlEQUF5QyxpQ0FBaUM7QUFDMUUsd0hBQWdILG1CQUFtQixFQUFFO0FBQ3JJO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsbUNBQTJCLDBCQUEwQixFQUFFO0FBQ3ZELHlDQUFpQyxlQUFlO0FBQ2hEO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDhEQUFzRCwrREFBK0Q7O0FBRXJIO0FBQ0E7OztBQUdBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUNsRkE7QUFBQTtBQUFlLE1BQU1BLGVBQU4sQ0FBc0I7QUFFakNDLE1BQUksR0FBRztBQUNIQyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxXQUFaO0FBQ0EsU0FBS0MsVUFBTDtBQUVIOztBQUVEQSxZQUFVLEdBQUc7QUFFVDtBQUNBLFFBQUlDLFNBQVMsR0FBR0MsTUFBTSxDQUFDQyxVQUFQLElBQXFCLEdBQXJDO0FBQ0EsUUFBSUMsUUFBUSxHQUFHRixNQUFNLENBQUNDLFVBQVAsR0FBb0IsR0FBcEIsSUFBMkJELE1BQU0sQ0FBQ0MsVUFBUCxJQUFxQixHQUEvRDtBQUNBLFFBQUlFLFFBQVEsR0FBR0gsTUFBTSxDQUFDQyxVQUFQLEdBQW9CLEdBQW5DLENBTFMsQ0FRVDs7QUFDQSxRQUFJRyxPQUFPLEdBQUdDLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3Qiw0QkFBeEIsQ0FBZCxDQVRTLENBVVQ7O0FBQ0EsUUFBSUMsWUFBWSxHQUFHRixRQUFRLENBQUNHLGdCQUFULENBQTBCLHFCQUExQixDQUFuQixDQVhTLENBWVQ7O0FBQ0EsUUFBSUMsVUFBVSxHQUFHSixRQUFRLENBQUNHLGdCQUFULENBQTBCLGdDQUExQixDQUFqQjtBQUVBLFFBQUlFLEtBQUssR0FBR0wsUUFBUSxDQUFDRyxnQkFBVCxDQUEwQix1QkFBMUIsQ0FBWixDQWZTLENBaUJUOztBQUNBLFFBQUlHLE1BQU0sR0FBR04sUUFBUSxDQUFDRyxnQkFBVCxDQUEwQixlQUExQixDQUFiLENBbEJTLENBbUJUOztBQUNBLFFBQUlJLFdBQVcsR0FBR1AsUUFBUSxDQUFDRyxnQkFBVCxDQUEwQixvQkFBMUIsQ0FBbEI7QUFFQSxRQUFJSyxRQUFRLEdBQUdSLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3Qiw0QkFBeEIsQ0FBZjtBQUlBTyxZQUFRLENBQUNDLGdCQUFULENBQTBCLE9BQTFCLEVBQW1DLFVBQVNDLEtBQVQsRUFBZ0I7QUFDL0M7QUFDQUYsY0FBUSxDQUFDRyxTQUFULENBQW1CQyxNQUFuQixDQUEwQixhQUExQixFQUYrQyxDQUcvQzs7QUFDQWIsYUFBTyxDQUFDWSxTQUFSLENBQWtCQyxNQUFsQixDQUF5QixrQkFBekI7QUFDSCxLQUxELEVBMUJTLENBbUNUOztBQUNBLFFBQUlmLFFBQVEsSUFBSUMsUUFBaEIsRUFBMEI7QUFFdEI7QUFDQVUsY0FBUSxDQUFDQyxnQkFBVCxDQUEwQixPQUExQixFQUFtQyxVQUFTQyxLQUFULEVBQWdCO0FBRS9DO0FBQ0EsYUFBSyxJQUFJRyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHUCxNQUFNLENBQUNRLE1BQTNCLEVBQW1DRCxDQUFDLEVBQXBDLEVBQXdDO0FBQ3BDUCxnQkFBTSxDQUFDTyxDQUFELENBQU4sQ0FBVUUsS0FBVixDQUFnQkMsT0FBaEIsR0FBMEIsTUFBMUI7QUFDSCxTQUw4QyxDQU8vQzs7O0FBQ0EsYUFBSyxJQUFJSCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHWCxZQUFZLENBQUNZLE1BQWpDLEVBQXlDRCxDQUFDLEVBQTFDLEVBQThDO0FBQzFDWCxzQkFBWSxDQUFDVyxDQUFELENBQVosQ0FBZ0JGLFNBQWhCLENBQTBCTSxNQUExQixDQUFpQyxpQkFBakM7QUFDQWYsc0JBQVksQ0FBQ1csQ0FBRCxDQUFaLENBQWdCRixTQUFoQixDQUEwQk0sTUFBMUIsQ0FBaUMsNEJBQWpDO0FBQ0FmLHNCQUFZLENBQUNXLENBQUQsQ0FBWixDQUFnQkssYUFBaEIsQ0FBOEJQLFNBQTlCLENBQXdDTSxNQUF4QyxDQUErQyxrQkFBL0M7QUFFSCxTQWI4QyxDQWUvQzs7O0FBQ0EsYUFBSyxJQUFJSixDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHUixLQUFLLENBQUNTLE1BQTFCLEVBQWtDRCxDQUFDLEVBQW5DLEVBQXVDO0FBQ25DUixlQUFLLENBQUNRLENBQUQsQ0FBTCxDQUFTRixTQUFULENBQW1CTSxNQUFuQixDQUEwQiw0QkFBMUI7QUFFSDtBQUVKLE9BckJELEVBSHNCLENBMEJ0Qjs7QUFDQWYsa0JBQVksQ0FBQ2lCLE9BQWIsQ0FBcUJDLElBQUksSUFBSTtBQUN6QkEsWUFBSSxDQUFDWCxnQkFBTCxDQUFzQixPQUF0QixFQUErQixNQUFNO0FBRWpDO0FBQ0FILGdCQUFNLENBQUNhLE9BQVAsQ0FBZUMsSUFBSSxJQUFJO0FBQ25CLGlCQUFLLElBQUlQLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdQLE1BQU0sQ0FBQ1EsTUFBM0IsRUFBbUNELENBQUMsRUFBcEMsRUFBd0M7QUFDcENQLG9CQUFNLENBQUNPLENBQUQsQ0FBTixDQUFVRSxLQUFWLENBQWdCQyxPQUFoQixHQUEwQixNQUExQjtBQUNIO0FBQ0osV0FKRCxFQUhpQyxDQVVqQzs7QUFDQSxjQUFJSyxHQUFHLEdBQUdELElBQUksQ0FBQ0Usa0JBQWYsQ0FYaUMsQ0FhakM7O0FBQ0FELGFBQUcsQ0FBQ04sS0FBSixDQUFVQyxPQUFWLEdBQW9CSyxHQUFHLENBQUNOLEtBQUosQ0FBVUMsT0FBVixLQUFzQixNQUF0QixHQUErQixPQUEvQixHQUF5QyxNQUE3RCxDQWRpQyxDQWdCakM7O0FBQ0EsY0FBSUssR0FBRyxHQUFHRCxJQUFJLENBQUNFLGtCQUFmO0FBQ0FELGFBQUcsQ0FBQ1YsU0FBSixDQUFjQyxNQUFkLENBQXFCLGlCQUFyQixFQWxCaUMsQ0FvQmpDOztBQUNBTCxxQkFBVyxDQUFDWSxPQUFaLENBQW9CQyxJQUFJLElBQUk7QUFDeEIsaUJBQUssSUFBSVAsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR04sV0FBVyxDQUFDTyxNQUFoQyxFQUF3Q0QsQ0FBQyxFQUF6QyxFQUE2QztBQUN6Q04seUJBQVcsQ0FBQ00sQ0FBRCxDQUFYLENBQWVGLFNBQWYsQ0FBeUJNLE1BQXpCLENBQWdDLDJCQUFoQztBQUNIO0FBQ0osV0FKRCxFQXJCaUMsQ0EyQmpDOztBQUVBLGNBQUlNLElBQUksR0FBR0gsSUFBSSxDQUFDSSxhQUFMLENBQW1CLHVCQUFuQixDQUFYO0FBQ0FELGNBQUksQ0FBQ1osU0FBTCxDQUFlQyxNQUFmLENBQXNCLDRCQUF0QjtBQUVBUSxjQUFJLENBQUNULFNBQUwsQ0FBZUMsTUFBZixDQUFzQixpQkFBdEI7QUFDQVEsY0FBSSxDQUFDVCxTQUFMLENBQWVDLE1BQWYsQ0FBc0IsNEJBQXRCO0FBQ0FRLGNBQUksQ0FBQ0YsYUFBTCxDQUFtQlAsU0FBbkIsQ0FBNkJDLE1BQTdCLENBQW9DLGtCQUFwQztBQUVILFNBcENEO0FBc0NILE9BdkNELEVBM0JzQixDQXNFdEI7O0FBQ0FMLGlCQUFXLENBQUNZLE9BQVosQ0FBb0JDLElBQUksSUFBSTtBQUN4QkEsWUFBSSxDQUFDWCxnQkFBTCxDQUFzQixPQUF0QixFQUErQixNQUFNO0FBQ2pDLGVBQUssSUFBSUksQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR04sV0FBVyxDQUFDTyxNQUFoQyxFQUF3Q0QsQ0FBQyxFQUF6QyxFQUE2QztBQUN6QztBQUNBTix1QkFBVyxDQUFDTSxDQUFELENBQVgsQ0FBZUYsU0FBZixDQUF5Qk0sTUFBekIsQ0FBZ0MsMkJBQWhDO0FBQ0g7O0FBQ0RHLGNBQUksQ0FBQ1QsU0FBTCxDQUFlQyxNQUFmLENBQXNCLDJCQUF0QjtBQUVILFNBUEQ7QUFTSCxPQVZEO0FBYUg7QUFFSjs7QUFsSWdDLEM7Ozs7Ozs7Ozs7OztBQ0FyQztBQUFBO0FBQUE7QUFBQTtBQUNBO0FBRUE7Ozs7O0FBSUFhLDhDQUFLLENBQUNDLGFBQU4sR0FBc0IsTUFBTTtBQUN4Qm5DLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLHFCQUFaLEVBRHdCLENBRXhCO0FBR0gsQ0FMRDtBQVFBOzs7Ozs7QUFJQWlDLDhDQUFLLENBQUNFLGdCQUFOLEdBQXlCLE1BQU07QUFDM0JwQyxTQUFPLENBQUNDLEdBQVIsQ0FBWSwwQkFBWixFQUQyQixDQUUzQjs7QUFFQSxNQUFJb0MsTUFBTSxHQUFHLElBQUl2Qyx5REFBSixFQUFiO0FBQ0F1QyxRQUFNLENBQUN0QyxJQUFQO0FBRUgsQ0FQRCxDOzs7Ozs7Ozs7Ozs7QUNuQkE7QUFBQTs7Ozs7O0FBUUEsTUFBTXVDLFlBQVksR0FBRyxrQkFBckI7QUFDQSxNQUFNQyxPQUFPLEdBQUc5QixRQUFRLENBQUN3QixhQUFULENBQXVCLHFCQUF2QixDQUFoQjtBQUNBLE1BQU1PLG1CQUFtQixHQUFHQyxPQUFPLENBQUNoQyxRQUFRLENBQUN3QixhQUFULENBQXVCSyxZQUF2QixDQUFELEVBQXVDLHNCQUF2QyxDQUFuQztBQUNBLE1BQU1JLGNBQWMsR0FBR0YsbUJBQW1CLEdBQUdBLG1CQUFtQixDQUFDRyxPQUFwQixDQUE0QkMsYUFBL0IsR0FBK0MsRUFBekY7QUFDQSxJQUFJQyxLQUFLLEdBQUdwQyxRQUFRLENBQUNxQyxlQUFULENBQXlCQyxXQUFyQztBQUNBLElBQUk1QyxTQUFTLEdBQUcwQyxLQUFLLEdBQUcsR0FBeEI7QUFDQSxJQUFJdkMsUUFBUSxHQUFHdUMsS0FBSyxJQUFJLEdBQVQsSUFBZ0JBLEtBQUssSUFBSSxHQUF4QztBQUNBLElBQUl0QyxRQUFRLEdBQUdzQyxLQUFLLEdBQUcsR0FBUixJQUFlQSxLQUFLLEdBQUcsR0FBdEM7QUFHQTs7Ozs7OztBQU1BLFNBQVNKLE9BQVQsQ0FBaUJPLEVBQWpCLEVBQXFCQyxRQUFyQixFQUErQkMsWUFBL0IsRUFBNkM7QUFDekMsTUFBSUMsTUFBTSxHQUFHLElBQWI7O0FBQ0EsU0FBT0gsRUFBUCxFQUFXO0FBQ1AsUUFBSUEsRUFBRSxDQUFDSSxPQUFILENBQVdILFFBQVgsQ0FBSixFQUEwQjtBQUN0QkUsWUFBTSxHQUFHSCxFQUFUO0FBQ0E7QUFDSCxLQUhELE1BR08sSUFBSUUsWUFBWSxJQUFJRixFQUFFLENBQUNJLE9BQUgsQ0FBV0YsWUFBWCxDQUFwQixFQUE4QztBQUNqRDtBQUNIOztBQUNERixNQUFFLEdBQUdBLEVBQUUsQ0FBQ3JCLGFBQVI7QUFDSDs7QUFDRCxTQUFPd0IsTUFBUDtBQUNIO0FBR0Q7Ozs7OztBQUlBLFNBQVNFLGdCQUFULEdBQTRCO0FBQ3hCNUMsVUFBUSxDQUFDd0IsYUFBVCxDQUF1QixrQkFBdkIsRUFBMkNxQixlQUEzQyxDQUEyRCxPQUEzRDtBQUNBQyxJQUFFLENBQUNDLFNBQUgsR0FBZSxJQUFmO0FBQ0FELElBQUUsQ0FBQ3BCLGFBQUg7QUFDSDtBQUdEOzs7Ozs7QUFJQSxTQUFTc0IsZUFBVCxHQUEyQjtBQUN2QnJELFFBQU0sQ0FBQ3NELElBQVAsQ0FBWUMsTUFBWixDQUFtQjVELElBQW5CLENBQXdCVSxRQUFRLENBQUN3QixhQUFULENBQXVCLGtCQUF2QixDQUF4Qjs7QUFDQXNCLElBQUUsQ0FBQ25CLGdCQUFIO0FBQ0g7QUFHRDs7Ozs7O0FBSUEsU0FBU3dCLGdCQUFULEdBQTRCO0FBQ3hCLFFBQU1DLFNBQVMsR0FBR3BELFFBQVEsQ0FBQ3FELFdBQTNCO0FBQ0EsTUFBSUMsUUFBUSxHQUFHLENBQWY7QUFDQSxLQUFHbkMsT0FBSCxDQUFXb0MsSUFBWCxDQUFnQkgsU0FBaEIsRUFBNEJoQyxJQUFELElBQVU7QUFDakMsVUFBTW9DLElBQUksR0FBR3BDLElBQUksQ0FBQ29DLElBQUwsSUFBYSxFQUExQjs7QUFDQSxRQUFJQSxJQUFJLENBQUNDLE9BQUwsQ0FBYSxNQUFiLE1BQXlCLENBQUMsQ0FBOUIsRUFBaUM7QUFDN0JsRSxhQUFPLENBQUNDLEdBQVIsQ0FBWSxhQUFaO0FBQ0E4RCxjQUFRO0FBQ1g7O0FBQ0QsUUFBSUUsSUFBSSxDQUFDQyxPQUFMLENBQWEsTUFBYixNQUF5QixDQUFDLENBQTlCLEVBQWlDO0FBQzdCbEUsYUFBTyxDQUFDQyxHQUFSLENBQVksaUJBQVo7QUFDQThELGNBQVE7QUFDWDtBQUNKLEdBVkQ7QUFXQSxTQUFRQSxRQUFRLEtBQUssQ0FBckI7QUFDSDs7QUFHRCxTQUFTaEUsSUFBVCxHQUFnQixDQUVmLENBRkQsQ0FDSTs7QUFHSjs7Ozs7QUFHQSxJQUFJLENBQUM2RCxnQkFBZ0IsRUFBckIsRUFBeUI7QUFDckJyQixTQUFPLENBQUNyQixnQkFBUixDQUF5QixNQUF6QixFQUFpQ21DLGdCQUFqQztBQUNILENBRkQsTUFFTyxJQUFJTyxnQkFBZ0IsRUFBcEIsRUFBd0I7QUFDM0JPLFlBQVUsQ0FBQ2QsZ0JBQUQsRUFBbUIsR0FBbkIsQ0FBVjtBQUNIO0FBR0Q7Ozs7O0FBR0EsSUFBSWpELE1BQU0sQ0FBQ3NELElBQVgsRUFBaUI7QUFDYlMsWUFBVSxDQUFDVixlQUFELEVBQWtCLEdBQWxCLENBQVY7QUFDSCxDQUZELE1BRU87QUFDSGhELFVBQVEsQ0FBQ1MsZ0JBQVQsQ0FBMEIscUJBQTFCLEVBQWlEdUMsZUFBakQ7QUFDSDs7QUFFRCxNQUFNRixFQUFFLEdBQUc7QUFDUHBELFdBRE87QUFFUEcsVUFGTztBQUdQQyxVQUhPO0FBSVA2RCxhQUFXLEVBQUU5QixZQUpOO0FBS1ArQixlQUFhLEVBQUUzQixjQUxSO0FBTVAzQyxNQUFJLEVBQUVBLElBTkM7QUFPUHlELFdBQVMsRUFBRSxLQVBKO0FBUVByQixlQUFhLEVBQUUsTUFBTSxJQVJkO0FBU1BDLGtCQUFnQixFQUFFLE1BQU07QUFUakIsQ0FBWDtBQVllbUIsaUVBQWYsRSIsImZpbGUiOiJtYWluLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSB7fTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZ2V0dGVyIH0pO1xuIFx0XHR9XG4gXHR9O1xuXG4gXHQvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSBmdW5jdGlvbihleHBvcnRzKSB7XG4gXHRcdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuIFx0XHR9XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG4gXHR9O1xuXG4gXHQvLyBjcmVhdGUgYSBmYWtlIG5hbWVzcGFjZSBvYmplY3RcbiBcdC8vIG1vZGUgJiAxOiB2YWx1ZSBpcyBhIG1vZHVsZSBpZCwgcmVxdWlyZSBpdFxuIFx0Ly8gbW9kZSAmIDI6IG1lcmdlIGFsbCBwcm9wZXJ0aWVzIG9mIHZhbHVlIGludG8gdGhlIG5zXG4gXHQvLyBtb2RlICYgNDogcmV0dXJuIHZhbHVlIHdoZW4gYWxyZWFkeSBucyBvYmplY3RcbiBcdC8vIG1vZGUgJiA4fDE6IGJlaGF2ZSBsaWtlIHJlcXVpcmVcbiBcdF9fd2VicGFja19yZXF1aXJlX18udCA9IGZ1bmN0aW9uKHZhbHVlLCBtb2RlKSB7XG4gXHRcdGlmKG1vZGUgJiAxKSB2YWx1ZSA9IF9fd2VicGFja19yZXF1aXJlX18odmFsdWUpO1xuIFx0XHRpZihtb2RlICYgOCkgcmV0dXJuIHZhbHVlO1xuIFx0XHRpZigobW9kZSAmIDQpICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgJiYgdmFsdWUuX19lc01vZHVsZSkgcmV0dXJuIHZhbHVlO1xuIFx0XHR2YXIgbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIobnMpO1xuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkobnMsICdkZWZhdWx0JywgeyBlbnVtZXJhYmxlOiB0cnVlLCB2YWx1ZTogdmFsdWUgfSk7XG4gXHRcdGlmKG1vZGUgJiAyICYmIHR5cGVvZiB2YWx1ZSAhPSAnc3RyaW5nJykgZm9yKHZhciBrZXkgaW4gdmFsdWUpIF9fd2VicGFja19yZXF1aXJlX18uZChucywga2V5LCBmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHZhbHVlW2tleV07IH0uYmluZChudWxsLCBrZXkpKTtcbiBcdFx0cmV0dXJuIG5zO1xuIFx0fTtcblxuIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubiA9IGZ1bmN0aW9uKG1vZHVsZSkge1xuIFx0XHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cbiBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuIFx0XHRcdGZ1bmN0aW9uIGdldE1vZHVsZUV4cG9ydHMoKSB7IHJldHVybiBtb2R1bGU7IH07XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsICdhJywgZ2V0dGVyKTtcbiBcdFx0cmV0dXJuIGdldHRlcjtcbiBcdH07XG5cbiBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vID0gZnVuY3Rpb24ob2JqZWN0LCBwcm9wZXJ0eSkgeyByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpOyB9O1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IFwiLi4vbWljcm9zaXRlcy1jYnUvMDItcGVyZm9ybWFuY2UvMDUtbWVudS9yZXNvdXJjZXMvc2NyaXB0cy9tYWluLmpzXCIpO1xuIiwiZXhwb3J0IGRlZmF1bHQgY2xhc3MgTWVudVBlcmZvcm1hbmNlIHtcblxuICAgIGluaXQoKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiSU5JVCBNRU5VXCIpO1xuICAgICAgICB0aGlzLm1lbnVNb2JpbGUoKTtcblxuICAgIH1cblxuICAgIG1lbnVNb2JpbGUoKSB7XG5cbiAgICAgICAgLy9EZXZpY2Ugd2lkdGggYW5kIG9yaWVudGF0aW9uXG4gICAgICAgIHZhciBpc0Rlc2t0b3AgPSB3aW5kb3cuaW5uZXJXaWR0aCA+PSA5NzA7XG4gICAgICAgIHZhciBpc1RhYmxldCA9IHdpbmRvdy5pbm5lcldpZHRoIDwgOTcwICYmIHdpbmRvdy5pbm5lcldpZHRoID49IDY0MDtcbiAgICAgICAgdmFyIGlzTW9iaWxlID0gd2luZG93LmlubmVyV2lkdGggPCA2NDA7XG5cblxuICAgICAgICAvL01haW4gbmF2IGNvbnRhaW5lclxuICAgICAgICB2YXIgbWFpbk5hdiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidmZtcy1tYWluLWhlYWRlcl9fbWFpbi1uYXZcIik7XG4gICAgICAgIC8vTWFpbiBtZW51IGl0ZW0uXG4gICAgICAgIHZhciBtYWluTmF2SXRlbXMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLnZmbXMtbWFpbi1uYXYtaXRlbVwiKTtcbiAgICAgICAgLy8gTWFpbiBOYXYgaXRlbSBjb250YWluZXJcbiAgICAgICAgdmFyIG1haW5OYXZCb3ggPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLnZmbXMtbWFpbi1uYXYtY29udGFpbmVyX19pdGVtXCIpO1xuXG4gICAgICAgIHZhciBpdGVtcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy52Zm1zLW1haW4taXRlbV9fdHlwZScpO1xuXG4gICAgICAgIC8vU2VjdW5kYXJ5IG5hdiBjb250YWluZXJcbiAgICAgICAgdmFyIHNlY05hdiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIudmZtcy1zZWMtbmF2XCIpO1xuICAgICAgICAvL1NlY3VuZGFyeSBuYXYgaXRlbXNcbiAgICAgICAgdmFyIHNlY05hdkl0ZW1zID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIi52Zm1zLXNlYy1uYXYtaXRlbVwiKTtcblxuICAgICAgICB2YXIgb3Blbk1lbnUgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndmZtcy1yZWN1cnNpdmUtbmF2X19idXR0b24nKTtcblxuXG5cbiAgICAgICAgb3Blbk1lbnUuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBmdW5jdGlvbihldmVudCkge1xuICAgICAgICAgICAgLy9jaGFuZ2UgaWNvbiBzaGFwZVxuICAgICAgICAgICAgb3Blbk1lbnUuY2xhc3NMaXN0LnRvZ2dsZShcInZmbXMtaXNPcGVuXCIpO1xuICAgICAgICAgICAgLy9TaG93IG1haW4gbmF2IGNvbnRhaW5lci4gQ2hhbmdlIGRpc3BsYXkgb2YgdGhlIGVsZW1lbnQuXG4gICAgICAgICAgICBtYWluTmF2LmNsYXNzTGlzdC50b2dnbGUoXCJ2Zm1zLXNob3dNYWluTmF2XCIpO1xuICAgICAgICB9KTtcblxuXG5cbiAgICAgICAgLy9UYWJsZXQgYW5kIE1vYmlsZS5cbiAgICAgICAgaWYgKGlzVGFibGV0IHx8IGlzTW9iaWxlKSB7XG5cbiAgICAgICAgICAgIC8vIEFMIHBpbmNoYXIgZW4gZWwgbWVuw7ogZGUgaGFtYnVyZ3Vlc2EgXG4gICAgICAgICAgICBvcGVuTWVudS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGZ1bmN0aW9uKGV2ZW50KSB7XG5cbiAgICAgICAgICAgICAgICAvLyBUb2RhcyBsYXMgbmF2ZWdhY2lvbmVzIHNlY3VuZGFyaWFzIGVzdGFyw6FuIGVzY29uZGlkYXNcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHNlY05hdi5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICBzZWNOYXZbaV0uc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vTG9zIGl0ZW1zIGRlIGxhIG5hdmVnYWNpw7NuIHByaW5jaXBhbCBubyBkZWJlbiBlc3RhciBlbiByb2pvIGFsIGRlc3BsZWdhcnNlIGVsIG1lbsO6XG4gICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBtYWluTmF2SXRlbXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgbWFpbk5hdkl0ZW1zW2ldLmNsYXNzTGlzdC5yZW1vdmUoXCJ2Zm1zLWNoYW5nZUljb25cIik7XG4gICAgICAgICAgICAgICAgICAgIG1haW5OYXZJdGVtc1tpXS5jbGFzc0xpc3QucmVtb3ZlKFwidmZlcy1jb2xvdXJzLS12b2RhZm9uZS1yZWRcIik7XG4gICAgICAgICAgICAgICAgICAgIG1haW5OYXZJdGVtc1tpXS5wYXJlbnRFbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoXCJ2Zm1zLWJvcmRlckNvbG9yXCIpO1xuXG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLy9Mb3MgaXRlbXMgZGUgbGEgbmF2ZWdhY2nDs24gcHJpbmNpcGFsIG5vIGRlYmVuIGVzdGFyIGVuIHJvam8gYWwgZGVzcGxlZ2Fyc2UgZWwgbWVuw7pcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGl0ZW1zLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIGl0ZW1zW2ldLmNsYXNzTGlzdC5yZW1vdmUoXCJ2ZmVzLWNvbG91cnMtLXZvZGFmb25lLXJlZFwiKTtcblxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIC8vRnVuY2lvbmVzIGNvcnJlc3BvbmRpZW50ZXMgYWwgZXZlbnRvIGNsaWNrIGRlIGxvcyBlbGVtZW50b3MgZGUgbGEgbmF2ZWdhY2nDs24gcHJpbmNpcGFsLlxuICAgICAgICAgICAgbWFpbk5hdkl0ZW1zLmZvckVhY2goaXRlbSA9PiB7XG4gICAgICAgICAgICAgICAgaXRlbS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcblxuICAgICAgICAgICAgICAgICAgICAvLyBUb2RhcyBsYXMgbmF2ZWdhY2lvbmVzIHNlY3VuZGFyaWFzIHRpZW5lbiBxdWUgZXN0YXIgZXNjb25kaWRhcyBtZW5vcyBsYSBxdWUgc2lndWUgYWwgcXVlIHNlIGVzdMOhIHBpbmNoYW5kby5cbiAgICAgICAgICAgICAgICAgICAgc2VjTmF2LmZvckVhY2goaXRlbSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHNlY05hdi5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlY05hdltpXS5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9KTtcblxuXG4gICAgICAgICAgICAgICAgICAgIC8vIC8vRWxlbWVudG8gZGUgbmF2ZWdhY2nDs24gc2VjdW5kYXJpYVxuICAgICAgICAgICAgICAgICAgICB2YXIgc2VjID0gaXRlbS5uZXh0RWxlbWVudFNpYmxpbmc7XG5cbiAgICAgICAgICAgICAgICAgICAgLy9zZWMuY2xhc3NMaXN0LnRvZ2dsZShcInZmbXMtc2hvd05hdlwiKTtcbiAgICAgICAgICAgICAgICAgICAgc2VjLnN0eWxlLmRpc3BsYXkgPSBzZWMuc3R5bGUuZGlzcGxheSA9PT0gJ25vbmUnID8gJ2Jsb2NrJyA6ICdub25lJztcblxuICAgICAgICAgICAgICAgICAgICAvL0VsZW1lbnRvIGRlIG5hdmVnYWNpw7NuIHNlY3VuZGFyaWFcbiAgICAgICAgICAgICAgICAgICAgdmFyIHNlYyA9IGl0ZW0ubmV4dEVsZW1lbnRTaWJsaW5nO1xuICAgICAgICAgICAgICAgICAgICBzZWMuY2xhc3NMaXN0LnRvZ2dsZShcInZmbXMtc2hvd1NlY05hdlwiKTtcblxuICAgICAgICAgICAgICAgICAgICAvLyBMb3MgZWxlbWVudG9zIGRlIGxhIG5hdmVnYWNpw7NuIHNlY3VuZGFyaWEgZGViZW4gZGUgdGVuZXIgZWwgZm9uZG8gYmxhbmNvLiBcbiAgICAgICAgICAgICAgICAgICAgc2VjTmF2SXRlbXMuZm9yRWFjaChpdGVtID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgc2VjTmF2SXRlbXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWNOYXZJdGVtc1tpXS5jbGFzc0xpc3QucmVtb3ZlKFwidmZlcy1jb2xvdXJzLWJnLWFsdW1pbml1bVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgLy9FbCBpdGVtIGNhbWJpYSBkZSBjb2xvclxuXG4gICAgICAgICAgICAgICAgICAgIHZhciB0eXBlID0gaXRlbS5xdWVyeVNlbGVjdG9yKFwiLnZmbXMtbWFpbi1pdGVtX190eXBlXCIpO1xuICAgICAgICAgICAgICAgICAgICB0eXBlLmNsYXNzTGlzdC50b2dnbGUoXCJ2ZmVzLWNvbG91cnMtLXZvZGFmb25lLXJlZFwiKTtcblxuICAgICAgICAgICAgICAgICAgICBpdGVtLmNsYXNzTGlzdC50b2dnbGUoXCJ2Zm1zLWNoYW5nZUljb25cIik7XG4gICAgICAgICAgICAgICAgICAgIGl0ZW0uY2xhc3NMaXN0LnRvZ2dsZShcInZmZXMtY29sb3Vycy0tdm9kYWZvbmUtcmVkXCIpO1xuICAgICAgICAgICAgICAgICAgICBpdGVtLnBhcmVudEVsZW1lbnQuY2xhc3NMaXN0LnRvZ2dsZShcInZmbXMtYm9yZGVyQ29sb3JcIik7XG5cbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgfSk7XG5cblxuXG4gICAgICAgICAgICAvL1NlY3VuZGFyeSBOYXZpZ2F0aW9uIEl0ZW1zIEV2ZW50IGNsaWNrIGNoYW5nZSB0aGUgaXRlbSBiYWNrZ3JvdW5kLlxuICAgICAgICAgICAgc2VjTmF2SXRlbXMuZm9yRWFjaChpdGVtID0+IHtcbiAgICAgICAgICAgICAgICBpdGVtLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHNlY05hdkl0ZW1zLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NsaWNrIGluIGFub3RoZXIgaXRlbSByZW1vdmUgYmFja2dyb3VuZCBjb2xvci5cbiAgICAgICAgICAgICAgICAgICAgICAgIHNlY05hdkl0ZW1zW2ldLmNsYXNzTGlzdC5yZW1vdmUoXCJ2ZmVzLWNvbG91cnMtYmctYWx1bWluaXVtXCIpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGl0ZW0uY2xhc3NMaXN0LnRvZ2dsZShcInZmZXMtY29sb3Vycy1iZy1hbHVtaW5pdW1cIik7XG5cbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgfSk7XG5cblxuICAgICAgICB9XG5cbiAgICB9XG5cbn0iLCJpbXBvcnQgdG9vbHMgZnJvbSAnLi90b29scyc7XG5pbXBvcnQgTWVudVBlcmZvcm1hbmNlIGZyb20gJy4vX21lbnUtcGVyZm9ybWFuY2UnO1xuXG4vKlxuICogICBNw6l0b2RvIHF1ZSBzZSBkaXNwYXJhIGN1YW5kbyBlbCB3czJyLnZYLmNzc1xuICogICB5YSBzZSBoYSBjYXJnYWRvIHkgaGEgcGludGFkbyBsYSB3ZWJcbiAqICovXG50b29scy5vblN0eWxlc1JlYWR5ID0gKCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKFwiU2l0ZSB2aXN1YWxseSByZWFkeVwiKTtcbiAgICAvLyBETyBTT01FVEhJTkdcblxuXG59O1xuXG5cbi8qXG4gKiAgIE3DqXRvZG8gcXVlIHNlIGRpc3BhcmEgY3VhbmRvIGVsIHdzMnIudlguanNcbiAqICAgeWEgc2UgaGEgY2FyZ2FkbyB5IGVzdMOhIGRpcG9uaWJsZS5cbiAqICovXG50b29scy5vbkZyYW1ld29ya1JlYWR5ID0gKCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKFwiU2l0ZSBmdW5jdGlvbmFsaXR5IHJlYWR5XCIpO1xuICAgIC8vIERPIFNPTUVUSElOR1xuXG4gICAgdmFyIG1pTWVudSA9IG5ldyBNZW51UGVyZm9ybWFuY2UoKTtcbiAgICBtaU1lbnUuaW5pdCgpO1xuXG59OyIsIi8qXG4gKiBNaWNyb3NpdGVzIHRvb2xzIGpzOlxuICogRXN0ZSBmaWNoZXJvIGVzIHVuYSBtdWVzdHJhIGRlIHV0aWxpZGFkZXMgcHJvcGlhcyBwYXJhIGxvcyBtaWNyb3NpdGVzLlxuICogU2UgcHVlZGUgcGVyc29uYWxpemFyIGEgdHUgZ3VzdG9cbiAqXG4gKi9cblxuXG5jb25zdCBNSUNST1NJVEVfSUQgPSAnI211bHRpcGVzdGFuYS12Mic7XG5jb25zdCBjc3NNYWluID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignbGlua1tkYXRhLW1pY3JvY3NzXScpO1xuY29uc3QgTUlDUk9TSVRFX1NFTEVDVElPTiA9IGNsb3Nlc3QoZG9jdW1lbnQucXVlcnlTZWxlY3RvcihNSUNST1NJVEVfSUQpLCAnW2RhdGEtcGF0aG1pY3Jvc2l0ZV0nKTtcbmNvbnN0IFBBVEhfTUlDUk9TSVRFID0gTUlDUk9TSVRFX1NFTEVDVElPTiA/IE1JQ1JPU0lURV9TRUxFQ1RJT04uZGF0YXNldC5wYXRobWljcm9zaXRlIDogJyc7XG5sZXQgd2lkdGggPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xpZW50V2lkdGg7XG5sZXQgaXNEZXNrdG9wID0gd2lkdGggPiA5Njk7XG5sZXQgaXNUYWJsZXQgPSB3aWR0aCA8PSA5NjkgJiYgd2lkdGggPj0gNzY4O1xubGV0IGlzTW9iaWxlID0gd2lkdGggPCA3NjggJiYgd2lkdGggPiAzMDA7XG5cblxuLypcbiogU2VhcmNoZXMgZm9yIHRoZSBwYXJlbnQgbm9kZSBjbG9zZXN0IHRvIHRoZSBlbGVtZW50LCB3aGljaCBjb21wbGllcyB3aXRoIHRoZSBzZWxlY3RvclxuKiBAcGFyYW0ge30gZWwgLSBEZXNjcmlwdGlvblxuKiBAcGFyYW0ge30gc2VsZWN0b3IgLSBEZXNjcmlwdGlvblxuKiBAcGFyYW0ge30gc3RvcFNlbGVjdG9yIC0gRGVzY3JpcHRpb25cbiogKi9cbmZ1bmN0aW9uIGNsb3Nlc3QoZWwsIHNlbGVjdG9yLCBzdG9wU2VsZWN0b3IpIHtcbiAgICBsZXQgcmV0dmFsID0gbnVsbDtcbiAgICB3aGlsZSAoZWwpIHtcbiAgICAgICAgaWYgKGVsLm1hdGNoZXMoc2VsZWN0b3IpKSB7XG4gICAgICAgICAgICByZXR2YWwgPSBlbDtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9IGVsc2UgaWYgKHN0b3BTZWxlY3RvciAmJiBlbC5tYXRjaGVzKHN0b3BTZWxlY3RvcikpIHtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGVsID0gZWwucGFyZW50RWxlbWVudDtcbiAgICB9XG4gICAgcmV0dXJuIHJldHZhbDtcbn1cblxuXG4vKlxuKiBSZW1vdmVzIHRoZSBzdHlsZSBhdHRyLCBvbmNlIHRoZSBzdHlsZXNoZWV0IGhhdmUgYmVlbiBsb2FkZWRcbiogcmV0dXJuIHVuZGVmaW5lZFxuKiAqL1xuZnVuY3Rpb24gX2ludGVybmFsQ1NTSW5pdCgpIHtcbiAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcudmZlcy1tcy1jb250ZW50JykucmVtb3ZlQXR0cmlidXRlKFwic3R5bGVcIik7XG4gICAgZXguY3NzTG9hZGVkID0gdHJ1ZTtcbiAgICBleC5vblN0eWxlc1JlYWR5KCk7XG59XG5cblxuLypcbiogSW5pdGlhbGl6ZXMgZnVuY3Rpb25hbGl0eSBKUywgYW5kIGFkdmljZXMgd2hlbiBKUyBpcyBsb2FkZWQuXG4qIHJldHVybiB1bmRlZmluZWRcbiogKi9cbmZ1bmN0aW9uIF9pbnRlcm5hbEpTSW5pdCgpIHtcbiAgICB3aW5kb3cudmZlcy5fdXRpbHMuaW5pdChkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcudmZlcy1tcy1jb250ZW50JykpO1xuICAgIGV4Lm9uRnJhbWV3b3JrUmVhZHkoKTtcbn1cblxuXG4vKlxuKiBDaGVjayBpZiBzdHlsZXNoZWV0IENTUyBpcyBsb2FkZWRcbiogQHJldHVybiB7Ym9vbGVhbn1cbiogKi9cbmZ1bmN0aW9uIGlzQ1NTTWljcm9Mb2FkZWQoKSB7XG4gICAgY29uc3QgZG9tU3R5bGVzID0gZG9jdW1lbnQuc3R5bGVTaGVldHM7XG4gICAgbGV0IGNvdW50Q1NTID0gMDtcbiAgICBbXS5mb3JFYWNoLmNhbGwoZG9tU3R5bGVzLCAoaXRlbSkgPT4ge1xuICAgICAgICBjb25zdCBocmVmID0gaXRlbS5ocmVmIHx8ICcnO1xuICAgICAgICBpZiAoaHJlZi5pbmRleE9mKCd3czJyJykgIT09IC0xKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnV1MyUiBMb2FkZWQnKTtcbiAgICAgICAgICAgIGNvdW50Q1NTKys7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGhyZWYuaW5kZXhPZignbWFpbicpICE9PSAtMSkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ01BSU4uQ1NTIExvYWRlZCcpO1xuICAgICAgICAgICAgY291bnRDU1MrK1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIChjb3VudENTUyA9PT0gMik7XG59XG5cblxuZnVuY3Rpb24gaW5pdCgpIHtcbiAgICAvLyBETyBTT01FVEhJTkdcbn1cblxuLypcbiogbGlzdGVuIGV2ZW50LCBvbmNlIGhhdmUgYmVlbiBsb2FkZWQgdGhlIGZpbGVzIENTU1xuKiAqL1xuaWYgKCFpc0NTU01pY3JvTG9hZGVkKCkpIHtcbiAgICBjc3NNYWluLmFkZEV2ZW50TGlzdGVuZXIoJ2xvYWQnLCBfaW50ZXJuYWxDU1NJbml0KTtcbn0gZWxzZSBpZiAoaXNDU1NNaWNyb0xvYWRlZCgpKSB7XG4gICAgc2V0VGltZW91dChfaW50ZXJuYWxDU1NJbml0LCAxMDApO1xufVxuXG5cbi8qXG4qIGxpc3RlbiBldmVudCwgb25jZSBoYXZlIGJlZW4gbG9hZGVkIHRoZSBmaWxlcyBKU1xuKiAqL1xuaWYgKHdpbmRvdy52ZmVzKSB7XG4gICAgc2V0VGltZW91dChfaW50ZXJuYWxKU0luaXQsIDEwMClcbn0gZWxzZSB7XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigndmZlczpmcmFtZXdvcmtSZWFkeScsIF9pbnRlcm5hbEpTSW5pdCk7XG59XG5cbmNvbnN0IGV4ID0ge1xuICAgIGlzRGVza3RvcCxcbiAgICBpc1RhYmxldCxcbiAgICBpc01vYmlsZSxcbiAgICBtaWNyb3NpdGVJZDogTUlDUk9TSVRFX0lELFxuICAgIG1pY3Jvc2l0ZVBhdGg6IFBBVEhfTUlDUk9TSVRFLFxuICAgIGluaXQ6IGluaXQsXG4gICAgY3NzTG9hZGVkOiBmYWxzZSxcbiAgICBvblN0eWxlc1JlYWR5OiAoKSA9PiBudWxsLFxuICAgIG9uRnJhbWV3b3JrUmVhZHk6ICgpID0+IG51bGxcbn07XG5cbmV4cG9ydCBkZWZhdWx0IGV4O1xuIl0sInNvdXJjZVJvb3QiOiIifQ==