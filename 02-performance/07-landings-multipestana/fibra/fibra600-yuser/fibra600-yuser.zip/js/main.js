/**
 * Vodafone Reboot Framework: Version 15.3.0. Generation Date: 2019-11-29T09:00:58.798Z
 */

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "../microsites-cbu/02-performance/landings-multipestana/fibra600-yuser/resources/scripts/main.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../microsites-cbu/02-performance/landings-multipestana/fibra600-yuser/resources/scripts/main.js":
/*!*******************************************************************************************************!*\
  !*** ../microsites-cbu/02-performance/landings-multipestana/fibra600-yuser/resources/scripts/main.js ***!
  \*******************************************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tools__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tools */ "../microsites-cbu/02-performance/landings-multipestana/fibra600-yuser/resources/scripts/tools.js");

/*
 *   Método que se dispara cuando el ws2r.vX.css
 *   ya se ha cargado y ha pintado la web
 * */

_tools__WEBPACK_IMPORTED_MODULE_0__["default"].onStylesReady = () => {
  console.log("Site visually ready"); // DO SOMETHING
};
/*
 *   Método que se dispara cuando el ws2r.vX.js
 *   ya se ha cargado y está diponible.
 * */


_tools__WEBPACK_IMPORTED_MODULE_0__["default"].onFrameworkReady = () => {
  console.log("Site functionality ready"); // DO SOMETHING
  // current date

  let current_datetime = new Date(); // console.log(current_datetime);
  // formated current date (YYYY-MM-DD)

  let formatted_date = current_datetime.getFullYear() + "-" + (current_datetime.getMonth() + 1) + "-" + current_datetime.getDate(); // console.log(formatted_date);
  // formated current date (YYYY-MM-DD hh:mm:ss)

  let current_formatted_date = current_datetime.getFullYear() + "-" + (current_datetime.getMonth() + 1) + "-" + current_datetime.getDate() + " " + pad(current_datetime.getHours()) + ":" + pad(current_datetime.getMinutes()) + ":" + pad(current_datetime.getSeconds()); // console.log(current_formatted_date);
  // Reset current date (YYYY-MM-DD 00:00:00)

  var fecha_inicio = formatted_date + ' ' + '00:00:00';
  var fecha_actual = current_formatted_date; // console.log(fecha_inicio);
  // console.log(fecha_actual);

  var fecha_inicio = new Date(fecha_inicio.replace(/\s/, 'T'));
  var fecha_actual = new Date(fecha_actual.replace(/\s/, 'T')); // console.log(typeof fecha_inicio);
  // console.log(typeof fecha_actual);

  var fechaInicio = new Date(fecha_inicio).getTime();
  var fechaFin = new Date(fecha_actual).getTime(); // console.log(fechaInicio);
  // console.log(fechaFin);
  //msec since day stats.

  var diff = fechaFin - fechaInicio; // console.log(typeof diff);
  // console.log(diff);
  // current week day (0 (sunday) y 6 (saturday)).

  var diaSemana = new Date().getDay();
  var diasRestantes = 7 - diaSemana; // msec que quedarían hasta el Lunes sin contar con los que ya han pasado.

  var milisegundosRestantes = diasRestantes * 24 * 60 * 60 * 1000; // msec remains to next Monday. Los segundos que quedarían hasta el Lunes menos los que ya han pasado del día, es decir, los 
  // milisegundos que quedarían realmente.

  var milisegundos = milisegundosRestantes - diff;
  var target_date = new Date().getTime() + milisegundos; // console.log(target_date);

  var days, hours, minutes, seconds; // variables for time units

  var countdown = document.getElementById("tiles"); // get tag element

  getCountdown();
  setInterval(function () {
    getCountdown();
  }, 1000);

  function getCountdown() {
    // find the amount of "seconds" between now and target
    var current_date = new Date().getTime();
    var seconds_left = (target_date - current_date) / 1000; // days = pad( parseInt(seconds_left / 86400) );

    days = pad(diasRestantes);
    seconds_left = seconds_left % 86400;
    hours = parseInt(pad(seconds_left / 3600));
    seconds_left = seconds_left % 3600;
    minutes = parseInt(pad(seconds_left / 60));
    seconds = parseInt(pad(seconds_left % 60));
    console.log(seconds);
    console.log('horas', typeof hours);
    console.log('minutes', typeof minutes);
    console.log('seconds', typeof seconds); // format countdown string + set tag value

    countdown.innerHTML = '<span>' + days + '</span><span>' + hours + '</span><span>' + minutes + '</span><span>' + seconds + '</span>';
  }

  function pad(i) {
    if (i < 10) {
      i = "0" + i;
    }

    return i;
  }
};

/***/ }),

/***/ "../microsites-cbu/02-performance/landings-multipestana/fibra600-yuser/resources/scripts/tools.js":
/*!********************************************************************************************************!*\
  !*** ../microsites-cbu/02-performance/landings-multipestana/fibra600-yuser/resources/scripts/tools.js ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/*
 * Microsites tools js:
 * Este fichero es una muestra de utilidades propias para los microsites.
 * Se puede personalizar a tu gusto
 *
 */
const MICROSITE_ID = '#fibra600';
const cssMain = document.querySelector('link[data-microcss]');
const MICROSITE_SELECTION = closest(document.querySelector(MICROSITE_ID), '[data-pathmicrosite]');
const PATH_MICROSITE = MICROSITE_SELECTION ? MICROSITE_SELECTION.dataset.pathmicrosite : '';
let width = document.documentElement.clientWidth;
let isDesktop = width > 969;
let isTablet = width <= 969 && width >= 768;
let isMobile = width < 768 && width > 300;
/*
* Searches for the parent node closest to the element, which complies with the selector
* @param {} el - Description
* @param {} selector - Description
* @param {} stopSelector - Description
* */

function closest(el, selector, stopSelector) {
  let retval = null;

  while (el) {
    if (el.matches(selector)) {
      retval = el;
      break;
    } else if (stopSelector && el.matches(stopSelector)) {
      break;
    }

    el = el.parentElement;
  }

  return retval;
}
/*
* Removes the style attr, once the stylesheet have been loaded
* return undefined
* */


function _internalCSSInit() {
  document.querySelector('.vfes-ms-content').removeAttribute("style");
  ex.cssLoaded = true;
  ex.onStylesReady();
}
/*
* Initializes functionality JS, and advices when JS is loaded.
* return undefined
* */


function _internalJSInit() {
  window.vfes._utils.init(document.querySelector('.vfes-ms-content'));

  ex.onFrameworkReady();
}
/*
* Check if stylesheet CSS is loaded
* @return {boolean}
* */


function isCSSMicroLoaded() {
  const domStyles = document.styleSheets;
  let countCSS = 0;
  [].forEach.call(domStyles, item => {
    const href = item.href || '';

    if (href.indexOf('ws2r') !== -1) {
      console.log('WS2RCSS Loaded');
      countCSS++;
    }

    if (href.indexOf(PATH_MICROSITE + 'css/styles.css') !== -1) {
      console.log('MICROCSS Loaded');
      countCSS++;
    }
  });
  return countCSS === 2;
}

function init() {} // DO SOMETHING

/*
* listen event, once have been loaded the files CSS
* */


if (!isCSSMicroLoaded()) {
  cssMain.addEventListener('load', _internalCSSInit);
} else if (isCSSMicroLoaded()) {
  setTimeout(_internalCSSInit, 100);
}
/*
* listen event, once have been loaded the files JS
* */


if (window.vfes) {
  setTimeout(_internalJSInit, 100);
} else {
  document.addEventListener('vfes:frameworkReady', _internalJSInit);
}

const ex = {
  isDesktop,
  isTablet,
  isMobile,
  micrositeId: MICROSITE_ID,
  micrositePath: PATH_MICROSITE,
  init: init,
  cssLoaded: false,
  onStylesReady: () => null,
  onFrameworkReady: () => null
};
/* harmony default export */ __webpack_exports__["default"] = (ex);

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4uL21pY3Jvc2l0ZXMtY2J1LzAyLXBlcmZvcm1hbmNlL2xhbmRpbmdzLW11bHRpcGVzdGFuYS9maWJyYTYwMC15dXNlci9yZXNvdXJjZXMvc2NyaXB0cy9tYWluLmpzIiwid2VicGFjazovLy8uLi9taWNyb3NpdGVzLWNidS8wMi1wZXJmb3JtYW5jZS9sYW5kaW5ncy1tdWx0aXBlc3RhbmEvZmlicmE2MDAteXVzZXIvcmVzb3VyY2VzL3NjcmlwdHMvdG9vbHMuanMiXSwibmFtZXMiOlsidG9vbHMiLCJvblN0eWxlc1JlYWR5IiwiY29uc29sZSIsImxvZyIsIm9uRnJhbWV3b3JrUmVhZHkiLCJjdXJyZW50X2RhdGV0aW1lIiwiRGF0ZSIsImZvcm1hdHRlZF9kYXRlIiwiZ2V0RnVsbFllYXIiLCJnZXRNb250aCIsImdldERhdGUiLCJjdXJyZW50X2Zvcm1hdHRlZF9kYXRlIiwicGFkIiwiZ2V0SG91cnMiLCJnZXRNaW51dGVzIiwiZ2V0U2Vjb25kcyIsImZlY2hhX2luaWNpbyIsImZlY2hhX2FjdHVhbCIsInJlcGxhY2UiLCJmZWNoYUluaWNpbyIsImdldFRpbWUiLCJmZWNoYUZpbiIsImRpZmYiLCJkaWFTZW1hbmEiLCJnZXREYXkiLCJkaWFzUmVzdGFudGVzIiwibWlsaXNlZ3VuZG9zUmVzdGFudGVzIiwibWlsaXNlZ3VuZG9zIiwidGFyZ2V0X2RhdGUiLCJkYXlzIiwiaG91cnMiLCJtaW51dGVzIiwic2Vjb25kcyIsImNvdW50ZG93biIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJnZXRDb3VudGRvd24iLCJzZXRJbnRlcnZhbCIsImN1cnJlbnRfZGF0ZSIsInNlY29uZHNfbGVmdCIsInBhcnNlSW50IiwiaW5uZXJIVE1MIiwiaSIsIk1JQ1JPU0lURV9JRCIsImNzc01haW4iLCJxdWVyeVNlbGVjdG9yIiwiTUlDUk9TSVRFX1NFTEVDVElPTiIsImNsb3Nlc3QiLCJQQVRIX01JQ1JPU0lURSIsImRhdGFzZXQiLCJwYXRobWljcm9zaXRlIiwid2lkdGgiLCJkb2N1bWVudEVsZW1lbnQiLCJjbGllbnRXaWR0aCIsImlzRGVza3RvcCIsImlzVGFibGV0IiwiaXNNb2JpbGUiLCJlbCIsInNlbGVjdG9yIiwic3RvcFNlbGVjdG9yIiwicmV0dmFsIiwibWF0Y2hlcyIsInBhcmVudEVsZW1lbnQiLCJfaW50ZXJuYWxDU1NJbml0IiwicmVtb3ZlQXR0cmlidXRlIiwiZXgiLCJjc3NMb2FkZWQiLCJfaW50ZXJuYWxKU0luaXQiLCJ3aW5kb3ciLCJ2ZmVzIiwiX3V0aWxzIiwiaW5pdCIsImlzQ1NTTWljcm9Mb2FkZWQiLCJkb21TdHlsZXMiLCJzdHlsZVNoZWV0cyIsImNvdW50Q1NTIiwiZm9yRWFjaCIsImNhbGwiLCJpdGVtIiwiaHJlZiIsImluZGV4T2YiLCJhZGRFdmVudExpc3RlbmVyIiwic2V0VGltZW91dCIsIm1pY3Jvc2l0ZUlkIiwibWljcm9zaXRlUGF0aCJdLCJtYXBwaW5ncyI6IjtBQUFBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7QUFHQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0Esa0RBQTBDLGdDQUFnQztBQUMxRTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGdFQUF3RCxrQkFBa0I7QUFDMUU7QUFDQSx5REFBaUQsY0FBYztBQUMvRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaURBQXlDLGlDQUFpQztBQUMxRSx3SEFBZ0gsbUJBQW1CLEVBQUU7QUFDckk7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBMkIsMEJBQTBCLEVBQUU7QUFDdkQseUNBQWlDLGVBQWU7QUFDaEQ7QUFDQTtBQUNBOztBQUVBO0FBQ0EsOERBQXNELCtEQUErRDs7QUFFckg7QUFDQTs7O0FBR0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ2xGQTtBQUFBO0FBQUE7QUFFQTs7Ozs7QUFJQUEsOENBQUssQ0FBQ0MsYUFBTixHQUFzQixNQUFNO0FBQ3hCQyxTQUFPLENBQUNDLEdBQVIsQ0FBWSxxQkFBWixFQUR3QixDQUV4QjtBQUdILENBTEQ7QUFRQTs7Ozs7O0FBSUFILDhDQUFLLENBQUNJLGdCQUFOLEdBQXlCLE1BQU07QUFDM0JGLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLDBCQUFaLEVBRDJCLENBRTNCO0FBR0E7O0FBQ0EsTUFBSUUsZ0JBQWdCLEdBQUcsSUFBSUMsSUFBSixFQUF2QixDQU4yQixDQU8zQjtBQUNBOztBQUNBLE1BQUlDLGNBQWMsR0FBR0YsZ0JBQWdCLENBQUNHLFdBQWpCLEtBQWlDLEdBQWpDLElBQXdDSCxnQkFBZ0IsQ0FBQ0ksUUFBakIsS0FBOEIsQ0FBdEUsSUFBMkUsR0FBM0UsR0FBaUZKLGdCQUFnQixDQUFDSyxPQUFqQixFQUF0RyxDQVQyQixDQVUzQjtBQUNBOztBQUNBLE1BQUlDLHNCQUFzQixHQUFHTixnQkFBZ0IsQ0FBQ0csV0FBakIsS0FBaUMsR0FBakMsSUFBd0NILGdCQUFnQixDQUFDSSxRQUFqQixLQUE4QixDQUF0RSxJQUEyRSxHQUEzRSxHQUFpRkosZ0JBQWdCLENBQUNLLE9BQWpCLEVBQWpGLEdBQThHLEdBQTlHLEdBQW9IRSxHQUFHLENBQUNQLGdCQUFnQixDQUFDUSxRQUFqQixFQUFELENBQXZILEdBQXVKLEdBQXZKLEdBQTZKRCxHQUFHLENBQUNQLGdCQUFnQixDQUFDUyxVQUFqQixFQUFELENBQWhLLEdBQWtNLEdBQWxNLEdBQXdNRixHQUFHLENBQUNQLGdCQUFnQixDQUFDVSxVQUFqQixFQUFELENBQXhPLENBWjJCLENBYzNCO0FBRUE7O0FBQ0EsTUFBSUMsWUFBWSxHQUFHVCxjQUFjLEdBQUcsR0FBakIsR0FBdUIsVUFBMUM7QUFDQSxNQUFJVSxZQUFZLEdBQUdOLHNCQUFuQixDQWxCMkIsQ0FvQjNCO0FBQ0E7O0FBRUEsTUFBSUssWUFBWSxHQUFHLElBQUlWLElBQUosQ0FBU1UsWUFBWSxDQUFDRSxPQUFiLENBQXFCLElBQXJCLEVBQTJCLEdBQTNCLENBQVQsQ0FBbkI7QUFDQSxNQUFJRCxZQUFZLEdBQUcsSUFBSVgsSUFBSixDQUFTVyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsSUFBckIsRUFBMkIsR0FBM0IsQ0FBVCxDQUFuQixDQXhCMkIsQ0EwQjNCO0FBQ0E7O0FBRUEsTUFBSUMsV0FBVyxHQUFHLElBQUliLElBQUosQ0FBU1UsWUFBVCxFQUF1QkksT0FBdkIsRUFBbEI7QUFDQSxNQUFJQyxRQUFRLEdBQUcsSUFBSWYsSUFBSixDQUFTVyxZQUFULEVBQXVCRyxPQUF2QixFQUFmLENBOUIyQixDQWdDM0I7QUFDQTtBQUdBOztBQUNBLE1BQUlFLElBQUksR0FBR0QsUUFBUSxHQUFHRixXQUF0QixDQXJDMkIsQ0FzQzNCO0FBRUE7QUFFQTs7QUFDQSxNQUFJSSxTQUFTLEdBQUcsSUFBSWpCLElBQUosR0FBV2tCLE1BQVgsRUFBaEI7QUFDQSxNQUFJQyxhQUFhLEdBQUcsSUFBSUYsU0FBeEIsQ0E1QzJCLENBOEMzQjs7QUFDQSxNQUFJRyxxQkFBcUIsR0FBR0QsYUFBYSxHQUFHLEVBQWhCLEdBQXFCLEVBQXJCLEdBQTBCLEVBQTFCLEdBQStCLElBQTNELENBL0MyQixDQWdEM0I7QUFDQTs7QUFDQSxNQUFJRSxZQUFZLEdBQUdELHFCQUFxQixHQUFHSixJQUEzQztBQUdBLE1BQUlNLFdBQVcsR0FBRyxJQUFJdEIsSUFBSixHQUFXYyxPQUFYLEtBQXVCTyxZQUF6QyxDQXJEMkIsQ0FzRDNCOztBQUdBLE1BQUlFLElBQUosRUFBVUMsS0FBVixFQUFpQkMsT0FBakIsRUFBMEJDLE9BQTFCLENBekQyQixDQXlEUTs7QUFFbkMsTUFBSUMsU0FBUyxHQUFHQyxRQUFRLENBQUNDLGNBQVQsQ0FBd0IsT0FBeEIsQ0FBaEIsQ0EzRDJCLENBMkR1Qjs7QUFFbERDLGNBQVk7QUFFWkMsYUFBVyxDQUFDLFlBQVc7QUFBRUQsZ0JBQVk7QUFBSyxHQUEvQixFQUFpQyxJQUFqQyxDQUFYOztBQUVBLFdBQVNBLFlBQVQsR0FBd0I7QUFFcEI7QUFDQSxRQUFJRSxZQUFZLEdBQUcsSUFBSWhDLElBQUosR0FBV2MsT0FBWCxFQUFuQjtBQUNBLFFBQUltQixZQUFZLEdBQUcsQ0FBQ1gsV0FBVyxHQUFHVSxZQUFmLElBQStCLElBQWxELENBSm9CLENBT3BCOztBQUNBVCxRQUFJLEdBQUdqQixHQUFHLENBQUNhLGFBQUQsQ0FBVjtBQUNBYyxnQkFBWSxHQUFHQSxZQUFZLEdBQUcsS0FBOUI7QUFFQVQsU0FBSyxHQUFHVSxRQUFRLENBQUM1QixHQUFHLENBQUMyQixZQUFZLEdBQUcsSUFBaEIsQ0FBSixDQUFoQjtBQUNBQSxnQkFBWSxHQUFHQSxZQUFZLEdBQUcsSUFBOUI7QUFFQVIsV0FBTyxHQUFHUyxRQUFRLENBQUM1QixHQUFHLENBQUMyQixZQUFZLEdBQUcsRUFBaEIsQ0FBSixDQUFsQjtBQUNBUCxXQUFPLEdBQUdRLFFBQVEsQ0FBQzVCLEdBQUcsQ0FBQzJCLFlBQVksR0FBRyxFQUFoQixDQUFKLENBQWxCO0FBQ0FyQyxXQUFPLENBQUNDLEdBQVIsQ0FBWTZCLE9BQVo7QUFFQTlCLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBcUIsT0FBTzJCLEtBQTVCO0FBQ0E1QixXQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaLEVBQXVCLE9BQU80QixPQUE5QjtBQUNBN0IsV0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWixFQUF1QixPQUFPNkIsT0FBOUIsRUFwQm9CLENBc0JwQjs7QUFDQUMsYUFBUyxDQUFDUSxTQUFWLEdBQXNCLFdBQVdaLElBQVgsR0FBa0IsZUFBbEIsR0FBb0NDLEtBQXBDLEdBQTRDLGVBQTVDLEdBQThEQyxPQUE5RCxHQUF3RSxlQUF4RSxHQUEwRkMsT0FBMUYsR0FBb0csU0FBMUg7QUFDSDs7QUFFRCxXQUFTcEIsR0FBVCxDQUFhOEIsQ0FBYixFQUFnQjtBQUNaLFFBQUlBLENBQUMsR0FBRyxFQUFSLEVBQVk7QUFDUkEsT0FBQyxHQUFHLE1BQU1BLENBQVY7QUFDSDs7QUFDRCxXQUFPQSxDQUFQO0FBQ0g7QUFHSixDQW5HRCxDOzs7Ozs7Ozs7Ozs7QUNsQkE7QUFBQTs7Ozs7O0FBUUEsTUFBTUMsWUFBWSxHQUFHLFdBQXJCO0FBQ0EsTUFBTUMsT0FBTyxHQUFHVixRQUFRLENBQUNXLGFBQVQsQ0FBdUIscUJBQXZCLENBQWhCO0FBQ0EsTUFBTUMsbUJBQW1CLEdBQUdDLE9BQU8sQ0FBQ2IsUUFBUSxDQUFDVyxhQUFULENBQXVCRixZQUF2QixDQUFELEVBQXVDLHNCQUF2QyxDQUFuQztBQUNBLE1BQU1LLGNBQWMsR0FBR0YsbUJBQW1CLEdBQUdBLG1CQUFtQixDQUFDRyxPQUFwQixDQUE0QkMsYUFBL0IsR0FBK0MsRUFBekY7QUFDQSxJQUFJQyxLQUFLLEdBQUdqQixRQUFRLENBQUNrQixlQUFULENBQXlCQyxXQUFyQztBQUNBLElBQUlDLFNBQVMsR0FBR0gsS0FBSyxHQUFHLEdBQXhCO0FBQ0EsSUFBSUksUUFBUSxHQUFHSixLQUFLLElBQUksR0FBVCxJQUFnQkEsS0FBSyxJQUFJLEdBQXhDO0FBQ0EsSUFBSUssUUFBUSxHQUFHTCxLQUFLLEdBQUcsR0FBUixJQUFlQSxLQUFLLEdBQUcsR0FBdEM7QUFHQTs7Ozs7OztBQU1BLFNBQVNKLE9BQVQsQ0FBaUJVLEVBQWpCLEVBQXFCQyxRQUFyQixFQUErQkMsWUFBL0IsRUFBNkM7QUFDekMsTUFBSUMsTUFBTSxHQUFHLElBQWI7O0FBQ0EsU0FBT0gsRUFBUCxFQUFXO0FBQ1AsUUFBSUEsRUFBRSxDQUFDSSxPQUFILENBQVdILFFBQVgsQ0FBSixFQUEwQjtBQUN0QkUsWUFBTSxHQUFHSCxFQUFUO0FBQ0E7QUFDSCxLQUhELE1BR08sSUFBSUUsWUFBWSxJQUFJRixFQUFFLENBQUNJLE9BQUgsQ0FBV0YsWUFBWCxDQUFwQixFQUE4QztBQUNqRDtBQUNIOztBQUNERixNQUFFLEdBQUdBLEVBQUUsQ0FBQ0ssYUFBUjtBQUNIOztBQUNELFNBQU9GLE1BQVA7QUFDSDtBQUdEOzs7Ozs7QUFJQSxTQUFTRyxnQkFBVCxHQUE0QjtBQUN4QjdCLFVBQVEsQ0FBQ1csYUFBVCxDQUF1QixrQkFBdkIsRUFBMkNtQixlQUEzQyxDQUEyRCxPQUEzRDtBQUNBQyxJQUFFLENBQUNDLFNBQUgsR0FBZSxJQUFmO0FBQ0FELElBQUUsQ0FBQ2hFLGFBQUg7QUFDSDtBQUdEOzs7Ozs7QUFJQSxTQUFTa0UsZUFBVCxHQUEyQjtBQUN2QkMsUUFBTSxDQUFDQyxJQUFQLENBQVlDLE1BQVosQ0FBbUJDLElBQW5CLENBQXdCckMsUUFBUSxDQUFDVyxhQUFULENBQXVCLGtCQUF2QixDQUF4Qjs7QUFDQW9CLElBQUUsQ0FBQzdELGdCQUFIO0FBQ0g7QUFHRDs7Ozs7O0FBSUEsU0FBU29FLGdCQUFULEdBQTRCO0FBQ3hCLFFBQU1DLFNBQVMsR0FBR3ZDLFFBQVEsQ0FBQ3dDLFdBQTNCO0FBQ0EsTUFBSUMsUUFBUSxHQUFHLENBQWY7QUFDQSxLQUFHQyxPQUFILENBQVdDLElBQVgsQ0FBZ0JKLFNBQWhCLEVBQTRCSyxJQUFELElBQVU7QUFDakMsVUFBTUMsSUFBSSxHQUFHRCxJQUFJLENBQUNDLElBQUwsSUFBYSxFQUExQjs7QUFDQSxRQUFJQSxJQUFJLENBQUNDLE9BQUwsQ0FBYSxNQUFiLE1BQXlCLENBQUMsQ0FBOUIsRUFBaUM7QUFDN0I5RSxhQUFPLENBQUNDLEdBQVIsQ0FBWSxnQkFBWjtBQUNBd0UsY0FBUTtBQUNYOztBQUNELFFBQUlJLElBQUksQ0FBQ0MsT0FBTCxDQUFhaEMsY0FBYyxHQUFHLGdCQUE5QixNQUFvRCxDQUFDLENBQXpELEVBQTREO0FBQ3hEOUMsYUFBTyxDQUFDQyxHQUFSLENBQVksaUJBQVo7QUFDQXdFLGNBQVE7QUFDWDtBQUNKLEdBVkQ7QUFXQSxTQUFRQSxRQUFRLEtBQUssQ0FBckI7QUFDSDs7QUFHRCxTQUFTSixJQUFULEdBQWdCLENBRWYsQ0FGRCxDQUNJOztBQUdKOzs7OztBQUdBLElBQUksQ0FBQ0MsZ0JBQWdCLEVBQXJCLEVBQXlCO0FBQ3JCNUIsU0FBTyxDQUFDcUMsZ0JBQVIsQ0FBeUIsTUFBekIsRUFBaUNsQixnQkFBakM7QUFDSCxDQUZELE1BRU8sSUFBSVMsZ0JBQWdCLEVBQXBCLEVBQXdCO0FBQzNCVSxZQUFVLENBQUNuQixnQkFBRCxFQUFtQixHQUFuQixDQUFWO0FBQ0g7QUFHRDs7Ozs7QUFHQSxJQUFJSyxNQUFNLENBQUNDLElBQVgsRUFBaUI7QUFDYmEsWUFBVSxDQUFDZixlQUFELEVBQWtCLEdBQWxCLENBQVY7QUFDSCxDQUZELE1BRU87QUFDSGpDLFVBQVEsQ0FBQytDLGdCQUFULENBQTBCLHFCQUExQixFQUFpRGQsZUFBakQ7QUFDSDs7QUFFRCxNQUFNRixFQUFFLEdBQUc7QUFDUFgsV0FETztBQUVQQyxVQUZPO0FBR1BDLFVBSE87QUFJUDJCLGFBQVcsRUFBRXhDLFlBSk47QUFLUHlDLGVBQWEsRUFBRXBDLGNBTFI7QUFNUHVCLE1BQUksRUFBRUEsSUFOQztBQU9QTCxXQUFTLEVBQUUsS0FQSjtBQVFQakUsZUFBYSxFQUFFLE1BQU0sSUFSZDtBQVNQRyxrQkFBZ0IsRUFBRSxNQUFNO0FBVGpCLENBQVg7QUFZZTZELGlFQUFmLEUiLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0ge307XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cblxuIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4gXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhfX3dlYnBhY2tfcmVxdWlyZV9fLnMgPSBcIi4uL21pY3Jvc2l0ZXMtY2J1LzAyLXBlcmZvcm1hbmNlL2xhbmRpbmdzLW11bHRpcGVzdGFuYS9maWJyYTYwMC15dXNlci9yZXNvdXJjZXMvc2NyaXB0cy9tYWluLmpzXCIpO1xuIiwiaW1wb3J0IHRvb2xzIGZyb20gJy4vdG9vbHMnO1xuXG4vKlxuICogICBNw6l0b2RvIHF1ZSBzZSBkaXNwYXJhIGN1YW5kbyBlbCB3czJyLnZYLmNzc1xuICogICB5YSBzZSBoYSBjYXJnYWRvIHkgaGEgcGludGFkbyBsYSB3ZWJcbiAqICovXG50b29scy5vblN0eWxlc1JlYWR5ID0gKCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKFwiU2l0ZSB2aXN1YWxseSByZWFkeVwiKTtcbiAgICAvLyBETyBTT01FVEhJTkdcblxuXG59O1xuXG5cbi8qXG4gKiAgIE3DqXRvZG8gcXVlIHNlIGRpc3BhcmEgY3VhbmRvIGVsIHdzMnIudlguanNcbiAqICAgeWEgc2UgaGEgY2FyZ2FkbyB5IGVzdMOhIGRpcG9uaWJsZS5cbiAqICovXG50b29scy5vbkZyYW1ld29ya1JlYWR5ID0gKCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKFwiU2l0ZSBmdW5jdGlvbmFsaXR5IHJlYWR5XCIpO1xuICAgIC8vIERPIFNPTUVUSElOR1xuXG5cbiAgICAvLyBjdXJyZW50IGRhdGVcbiAgICBsZXQgY3VycmVudF9kYXRldGltZSA9IG5ldyBEYXRlKCk7XG4gICAgLy8gY29uc29sZS5sb2coY3VycmVudF9kYXRldGltZSk7XG4gICAgLy8gZm9ybWF0ZWQgY3VycmVudCBkYXRlIChZWVlZLU1NLUREKVxuICAgIGxldCBmb3JtYXR0ZWRfZGF0ZSA9IGN1cnJlbnRfZGF0ZXRpbWUuZ2V0RnVsbFllYXIoKSArIFwiLVwiICsgKGN1cnJlbnRfZGF0ZXRpbWUuZ2V0TW9udGgoKSArIDEpICsgXCItXCIgKyBjdXJyZW50X2RhdGV0aW1lLmdldERhdGUoKTtcbiAgICAvLyBjb25zb2xlLmxvZyhmb3JtYXR0ZWRfZGF0ZSk7XG4gICAgLy8gZm9ybWF0ZWQgY3VycmVudCBkYXRlIChZWVlZLU1NLUREIGhoOm1tOnNzKVxuICAgIGxldCBjdXJyZW50X2Zvcm1hdHRlZF9kYXRlID0gY3VycmVudF9kYXRldGltZS5nZXRGdWxsWWVhcigpICsgXCItXCIgKyAoY3VycmVudF9kYXRldGltZS5nZXRNb250aCgpICsgMSkgKyBcIi1cIiArIGN1cnJlbnRfZGF0ZXRpbWUuZ2V0RGF0ZSgpICsgXCIgXCIgKyBwYWQoY3VycmVudF9kYXRldGltZS5nZXRIb3VycygpKSArIFwiOlwiICsgcGFkKGN1cnJlbnRfZGF0ZXRpbWUuZ2V0TWludXRlcygpKSArIFwiOlwiICsgcGFkKGN1cnJlbnRfZGF0ZXRpbWUuZ2V0U2Vjb25kcygpKTtcblxuICAgIC8vIGNvbnNvbGUubG9nKGN1cnJlbnRfZm9ybWF0dGVkX2RhdGUpO1xuXG4gICAgLy8gUmVzZXQgY3VycmVudCBkYXRlIChZWVlZLU1NLUREIDAwOjAwOjAwKVxuICAgIHZhciBmZWNoYV9pbmljaW8gPSBmb3JtYXR0ZWRfZGF0ZSArICcgJyArICcwMDowMDowMCc7XG4gICAgdmFyIGZlY2hhX2FjdHVhbCA9IGN1cnJlbnRfZm9ybWF0dGVkX2RhdGU7XG5cbiAgICAvLyBjb25zb2xlLmxvZyhmZWNoYV9pbmljaW8pO1xuICAgIC8vIGNvbnNvbGUubG9nKGZlY2hhX2FjdHVhbCk7XG5cbiAgICB2YXIgZmVjaGFfaW5pY2lvID0gbmV3IERhdGUoZmVjaGFfaW5pY2lvLnJlcGxhY2UoL1xccy8sICdUJykpO1xuICAgIHZhciBmZWNoYV9hY3R1YWwgPSBuZXcgRGF0ZShmZWNoYV9hY3R1YWwucmVwbGFjZSgvXFxzLywgJ1QnKSk7XG5cbiAgICAvLyBjb25zb2xlLmxvZyh0eXBlb2YgZmVjaGFfaW5pY2lvKTtcbiAgICAvLyBjb25zb2xlLmxvZyh0eXBlb2YgZmVjaGFfYWN0dWFsKTtcblxuICAgIHZhciBmZWNoYUluaWNpbyA9IG5ldyBEYXRlKGZlY2hhX2luaWNpbykuZ2V0VGltZSgpO1xuICAgIHZhciBmZWNoYUZpbiA9IG5ldyBEYXRlKGZlY2hhX2FjdHVhbCkuZ2V0VGltZSgpO1xuXG4gICAgLy8gY29uc29sZS5sb2coZmVjaGFJbmljaW8pO1xuICAgIC8vIGNvbnNvbGUubG9nKGZlY2hhRmluKTtcblxuXG4gICAgLy9tc2VjIHNpbmNlIGRheSBzdGF0cy5cbiAgICB2YXIgZGlmZiA9IGZlY2hhRmluIC0gZmVjaGFJbmljaW87XG4gICAgLy8gY29uc29sZS5sb2codHlwZW9mIGRpZmYpO1xuXG4gICAgLy8gY29uc29sZS5sb2coZGlmZik7XG5cbiAgICAvLyBjdXJyZW50IHdlZWsgZGF5ICgwIChzdW5kYXkpIHkgNiAoc2F0dXJkYXkpKS5cbiAgICB2YXIgZGlhU2VtYW5hID0gbmV3IERhdGUoKS5nZXREYXkoKTtcbiAgICB2YXIgZGlhc1Jlc3RhbnRlcyA9IDcgLSBkaWFTZW1hbmE7XG5cbiAgICAvLyBtc2VjIHF1ZSBxdWVkYXLDrWFuIGhhc3RhIGVsIEx1bmVzIHNpbiBjb250YXIgY29uIGxvcyBxdWUgeWEgaGFuIHBhc2Fkby5cbiAgICB2YXIgbWlsaXNlZ3VuZG9zUmVzdGFudGVzID0gZGlhc1Jlc3RhbnRlcyAqIDI0ICogNjAgKiA2MCAqIDEwMDA7XG4gICAgLy8gbXNlYyByZW1haW5zIHRvIG5leHQgTW9uZGF5LiBMb3Mgc2VndW5kb3MgcXVlIHF1ZWRhcsOtYW4gaGFzdGEgZWwgTHVuZXMgbWVub3MgbG9zIHF1ZSB5YSBoYW4gcGFzYWRvIGRlbCBkw61hLCBlcyBkZWNpciwgbG9zIFxuICAgIC8vIG1pbGlzZWd1bmRvcyBxdWUgcXVlZGFyw61hbiByZWFsbWVudGUuXG4gICAgdmFyIG1pbGlzZWd1bmRvcyA9IG1pbGlzZWd1bmRvc1Jlc3RhbnRlcyAtIGRpZmY7XG5cblxuICAgIHZhciB0YXJnZXRfZGF0ZSA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpICsgbWlsaXNlZ3VuZG9zO1xuICAgIC8vIGNvbnNvbGUubG9nKHRhcmdldF9kYXRlKTtcblxuXG4gICAgdmFyIGRheXMsIGhvdXJzLCBtaW51dGVzLCBzZWNvbmRzOyAvLyB2YXJpYWJsZXMgZm9yIHRpbWUgdW5pdHNcblxuICAgIHZhciBjb3VudGRvd24gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRpbGVzXCIpOyAvLyBnZXQgdGFnIGVsZW1lbnRcblxuICAgIGdldENvdW50ZG93bigpO1xuXG4gICAgc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKSB7IGdldENvdW50ZG93bigpOyB9LCAxMDAwKTtcblxuICAgIGZ1bmN0aW9uIGdldENvdW50ZG93bigpIHtcblxuICAgICAgICAvLyBmaW5kIHRoZSBhbW91bnQgb2YgXCJzZWNvbmRzXCIgYmV0d2VlbiBub3cgYW5kIHRhcmdldFxuICAgICAgICB2YXIgY3VycmVudF9kYXRlID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICAgIHZhciBzZWNvbmRzX2xlZnQgPSAodGFyZ2V0X2RhdGUgLSBjdXJyZW50X2RhdGUpIC8gMTAwMDtcblxuXG4gICAgICAgIC8vIGRheXMgPSBwYWQoIHBhcnNlSW50KHNlY29uZHNfbGVmdCAvIDg2NDAwKSApO1xuICAgICAgICBkYXlzID0gcGFkKGRpYXNSZXN0YW50ZXMpO1xuICAgICAgICBzZWNvbmRzX2xlZnQgPSBzZWNvbmRzX2xlZnQgJSA4NjQwMDtcblxuICAgICAgICBob3VycyA9IHBhcnNlSW50KHBhZChzZWNvbmRzX2xlZnQgLyAzNjAwKSk7XG4gICAgICAgIHNlY29uZHNfbGVmdCA9IHNlY29uZHNfbGVmdCAlIDM2MDA7XG5cbiAgICAgICAgbWludXRlcyA9IHBhcnNlSW50KHBhZChzZWNvbmRzX2xlZnQgLyA2MCkpO1xuICAgICAgICBzZWNvbmRzID0gcGFyc2VJbnQocGFkKHNlY29uZHNfbGVmdCAlIDYwKSk7XG4gICAgICAgIGNvbnNvbGUubG9nKHNlY29uZHMpO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKCdob3JhcycsIHR5cGVvZiBob3Vycyk7XG4gICAgICAgIGNvbnNvbGUubG9nKCdtaW51dGVzJywgdHlwZW9mIG1pbnV0ZXMpO1xuICAgICAgICBjb25zb2xlLmxvZygnc2Vjb25kcycsIHR5cGVvZiBzZWNvbmRzKTtcblxuICAgICAgICAvLyBmb3JtYXQgY291bnRkb3duIHN0cmluZyArIHNldCB0YWcgdmFsdWVcbiAgICAgICAgY291bnRkb3duLmlubmVySFRNTCA9ICc8c3Bhbj4nICsgZGF5cyArICc8L3NwYW4+PHNwYW4+JyArIGhvdXJzICsgJzwvc3Bhbj48c3Bhbj4nICsgbWludXRlcyArICc8L3NwYW4+PHNwYW4+JyArIHNlY29uZHMgKyAnPC9zcGFuPic7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gcGFkKGkpIHtcbiAgICAgICAgaWYgKGkgPCAxMCkge1xuICAgICAgICAgICAgaSA9IFwiMFwiICsgaTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gaTtcbiAgICB9XG5cblxufTsiLCIvKlxuICogTWljcm9zaXRlcyB0b29scyBqczpcbiAqIEVzdGUgZmljaGVybyBlcyB1bmEgbXVlc3RyYSBkZSB1dGlsaWRhZGVzIHByb3BpYXMgcGFyYSBsb3MgbWljcm9zaXRlcy5cbiAqIFNlIHB1ZWRlIHBlcnNvbmFsaXphciBhIHR1IGd1c3RvXG4gKlxuICovXG5cblxuY29uc3QgTUlDUk9TSVRFX0lEID0gJyNmaWJyYTYwMCc7XG5jb25zdCBjc3NNYWluID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignbGlua1tkYXRhLW1pY3JvY3NzXScpO1xuY29uc3QgTUlDUk9TSVRFX1NFTEVDVElPTiA9IGNsb3Nlc3QoZG9jdW1lbnQucXVlcnlTZWxlY3RvcihNSUNST1NJVEVfSUQpLCAnW2RhdGEtcGF0aG1pY3Jvc2l0ZV0nKTtcbmNvbnN0IFBBVEhfTUlDUk9TSVRFID0gTUlDUk9TSVRFX1NFTEVDVElPTiA/IE1JQ1JPU0lURV9TRUxFQ1RJT04uZGF0YXNldC5wYXRobWljcm9zaXRlIDogJyc7XG5sZXQgd2lkdGggPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xpZW50V2lkdGg7XG5sZXQgaXNEZXNrdG9wID0gd2lkdGggPiA5Njk7XG5sZXQgaXNUYWJsZXQgPSB3aWR0aCA8PSA5NjkgJiYgd2lkdGggPj0gNzY4O1xubGV0IGlzTW9iaWxlID0gd2lkdGggPCA3NjggJiYgd2lkdGggPiAzMDA7XG5cblxuLypcbiogU2VhcmNoZXMgZm9yIHRoZSBwYXJlbnQgbm9kZSBjbG9zZXN0IHRvIHRoZSBlbGVtZW50LCB3aGljaCBjb21wbGllcyB3aXRoIHRoZSBzZWxlY3RvclxuKiBAcGFyYW0ge30gZWwgLSBEZXNjcmlwdGlvblxuKiBAcGFyYW0ge30gc2VsZWN0b3IgLSBEZXNjcmlwdGlvblxuKiBAcGFyYW0ge30gc3RvcFNlbGVjdG9yIC0gRGVzY3JpcHRpb25cbiogKi9cbmZ1bmN0aW9uIGNsb3Nlc3QoZWwsIHNlbGVjdG9yLCBzdG9wU2VsZWN0b3IpIHtcbiAgICBsZXQgcmV0dmFsID0gbnVsbDtcbiAgICB3aGlsZSAoZWwpIHtcbiAgICAgICAgaWYgKGVsLm1hdGNoZXMoc2VsZWN0b3IpKSB7XG4gICAgICAgICAgICByZXR2YWwgPSBlbDtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9IGVsc2UgaWYgKHN0b3BTZWxlY3RvciAmJiBlbC5tYXRjaGVzKHN0b3BTZWxlY3RvcikpIHtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGVsID0gZWwucGFyZW50RWxlbWVudDtcbiAgICB9XG4gICAgcmV0dXJuIHJldHZhbDtcbn1cblxuXG4vKlxuKiBSZW1vdmVzIHRoZSBzdHlsZSBhdHRyLCBvbmNlIHRoZSBzdHlsZXNoZWV0IGhhdmUgYmVlbiBsb2FkZWRcbiogcmV0dXJuIHVuZGVmaW5lZFxuKiAqL1xuZnVuY3Rpb24gX2ludGVybmFsQ1NTSW5pdCgpIHtcbiAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcudmZlcy1tcy1jb250ZW50JykucmVtb3ZlQXR0cmlidXRlKFwic3R5bGVcIik7XG4gICAgZXguY3NzTG9hZGVkID0gdHJ1ZTtcbiAgICBleC5vblN0eWxlc1JlYWR5KCk7XG59XG5cblxuLypcbiogSW5pdGlhbGl6ZXMgZnVuY3Rpb25hbGl0eSBKUywgYW5kIGFkdmljZXMgd2hlbiBKUyBpcyBsb2FkZWQuXG4qIHJldHVybiB1bmRlZmluZWRcbiogKi9cbmZ1bmN0aW9uIF9pbnRlcm5hbEpTSW5pdCgpIHtcbiAgICB3aW5kb3cudmZlcy5fdXRpbHMuaW5pdChkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcudmZlcy1tcy1jb250ZW50JykpO1xuICAgIGV4Lm9uRnJhbWV3b3JrUmVhZHkoKTtcbn1cblxuXG4vKlxuKiBDaGVjayBpZiBzdHlsZXNoZWV0IENTUyBpcyBsb2FkZWRcbiogQHJldHVybiB7Ym9vbGVhbn1cbiogKi9cbmZ1bmN0aW9uIGlzQ1NTTWljcm9Mb2FkZWQoKSB7XG4gICAgY29uc3QgZG9tU3R5bGVzID0gZG9jdW1lbnQuc3R5bGVTaGVldHM7XG4gICAgbGV0IGNvdW50Q1NTID0gMDtcbiAgICBbXS5mb3JFYWNoLmNhbGwoZG9tU3R5bGVzLCAoaXRlbSkgPT4ge1xuICAgICAgICBjb25zdCBocmVmID0gaXRlbS5ocmVmIHx8ICcnO1xuICAgICAgICBpZiAoaHJlZi5pbmRleE9mKCd3czJyJykgIT09IC0xKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnV1MyUkNTUyBMb2FkZWQnKTtcbiAgICAgICAgICAgIGNvdW50Q1NTKys7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGhyZWYuaW5kZXhPZihQQVRIX01JQ1JPU0lURSArICdjc3Mvc3R5bGVzLmNzcycpICE9PSAtMSkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ01JQ1JPQ1NTIExvYWRlZCcpO1xuICAgICAgICAgICAgY291bnRDU1MrK1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIChjb3VudENTUyA9PT0gMik7XG59XG5cblxuZnVuY3Rpb24gaW5pdCgpIHtcbiAgICAvLyBETyBTT01FVEhJTkdcbn1cblxuLypcbiogbGlzdGVuIGV2ZW50LCBvbmNlIGhhdmUgYmVlbiBsb2FkZWQgdGhlIGZpbGVzIENTU1xuKiAqL1xuaWYgKCFpc0NTU01pY3JvTG9hZGVkKCkpIHtcbiAgICBjc3NNYWluLmFkZEV2ZW50TGlzdGVuZXIoJ2xvYWQnLCBfaW50ZXJuYWxDU1NJbml0KTtcbn0gZWxzZSBpZiAoaXNDU1NNaWNyb0xvYWRlZCgpKSB7XG4gICAgc2V0VGltZW91dChfaW50ZXJuYWxDU1NJbml0LCAxMDApO1xufVxuXG5cbi8qXG4qIGxpc3RlbiBldmVudCwgb25jZSBoYXZlIGJlZW4gbG9hZGVkIHRoZSBmaWxlcyBKU1xuKiAqL1xuaWYgKHdpbmRvdy52ZmVzKSB7XG4gICAgc2V0VGltZW91dChfaW50ZXJuYWxKU0luaXQsIDEwMClcbn0gZWxzZSB7XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigndmZlczpmcmFtZXdvcmtSZWFkeScsIF9pbnRlcm5hbEpTSW5pdCk7XG59XG5cbmNvbnN0IGV4ID0ge1xuICAgIGlzRGVza3RvcCxcbiAgICBpc1RhYmxldCxcbiAgICBpc01vYmlsZSxcbiAgICBtaWNyb3NpdGVJZDogTUlDUk9TSVRFX0lELFxuICAgIG1pY3Jvc2l0ZVBhdGg6IFBBVEhfTUlDUk9TSVRFLFxuICAgIGluaXQ6IGluaXQsXG4gICAgY3NzTG9hZGVkOiBmYWxzZSxcbiAgICBvblN0eWxlc1JlYWR5OiAoKSA9PiBudWxsLFxuICAgIG9uRnJhbWV3b3JrUmVhZHk6ICgpID0+IG51bGxcbn07XG5cbmV4cG9ydCBkZWZhdWx0IGV4O1xuIl0sInNvdXJjZVJvb3QiOiIifQ==