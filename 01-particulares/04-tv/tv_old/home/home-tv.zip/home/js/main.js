/**
 * Vodafone Reboot Framework: Version 15.7.0. Generation Date: 2020-05-07T15:22:41.834Z
 */

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "../microsites-cbu/01-particulares/04-tv/tv/home/resources/scripts/main.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../microsites-cbu/01-particulares/04-tv/tv/home/resources/scripts/_tab-group.ws10.js":
/*!********************************************************************************************!*\
  !*** ../microsites-cbu/01-particulares/04-tv/tv/home/resources/scripts/_tab-group.ws10.js ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TabGroupWs10; });
const defaults = {
  $element: undefined,
  selectors: {},
  classes: {
    tabActive: `vfes-tab-group__container-item--active`
  }
};
/**
 * Tabs.
 *
 * @module TabGroupWs10
 * @param {Object} properties - specifies the configurations
 * for the module.
 */

class TabGroupWs10 {
  constructor(properties = {}) {
    this.$element = properties.$element;
    this.selectors = defaults.selectors;
    this.classes = defaults.classes;
    this.tabContainer = this.$element.querySelector(`[data-tab="tab-container"]`);
    this.tabsItem = this.tabContainer.querySelectorAll(`[role="tab"]`);
    this.onChanged = new Event('vfes:changed');
  }

  a11y() {
    [...this.tabsItem].forEach(tab => {
      if (!tab.hasAttribute("role") === "tab" || !tab.hasAttribute("data-option")) {
        console.log('Las tabs group tienen que tener los atributos: "role" con el valor de tab, "aria-selected" con un valor true o false, "data-option" con un valor numérico');
      }
    });
  }
  /**
   * Initialise the module.
   *
   * @function init
   *
   * @return undefined
   */


  init() {
    this.bind();
    this.a11y();
  }
  /**
   * Bind the events to the actionable elements
   * within the tabs system.
   *
   * @function bind
   *
   * @return undefined
   */


  bind() {
    const mod = this;
    [...mod.tabsItem].forEach(tab => {
      tab.addEventListener('click', () => {
        if (tab.getAttribute('data-tab-active') === 'false') {
          let activeTab = mod.getTabActive(); // Pestaña actual activada

          activeTab.classList.remove(mod.classes.tabActive);
          activeTab.setAttribute('data-tab-active', 'false');
          mod.$element.children[activeTab.getAttribute('aria-controls')].setAttribute('aria-expanded', 'false'); // Nueva pestaña a activar

          tab.classList.add(mod.classes.tabActive);
          tab.setAttribute('data-tab-active', 'true');
          mod.$element.children[tab.getAttribute('aria-controls')].setAttribute('aria-expanded', 'true');
          mod.onChanged.tab = tab;
          mod.onChanged.title = tab.innerText;
          mod.onChanged.index = tab.getAttribute('data-option');
          mod.onChanged.contentTab = mod.$element.querySelector(`[aria-expanded="true"]`);
          mod.$element.dispatchEvent(mod.onChanged);
        }
      });
    });
    this.tabContainer.addEventListener('click', () => {
      this.tabContainer.getAttribute('aria-expanded') === 'false' ? this.tabContainer.setAttribute('aria-expanded', 'true') : this.tabContainer.setAttribute('aria-expanded', 'false');
    });
  }

  getTabActive() {
    return this.tabContainer.querySelector(`[data-tab-active="true"]`);
  }

}

/***/ }),

/***/ "../microsites-cbu/01-particulares/04-tv/tv/home/resources/scripts/main.js":
/*!*********************************************************************************!*\
  !*** ../microsites-cbu/01-particulares/04-tv/tv/home/resources/scripts/main.js ***!
  \*********************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tools__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tools */ "../microsites-cbu/01-particulares/04-tv/tv/home/resources/scripts/tools.js");
/* harmony import */ var _tab_group_ws10__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_tab-group.ws10 */ "../microsites-cbu/01-particulares/04-tv/tv/home/resources/scripts/_tab-group.ws10.js");


/*
*   Método que se dispara cuando el ws2r.vX.css
*   ya se ha cargado y ha pintado la web
* */

_tools__WEBPACK_IMPORTED_MODULE_0__["default"].onStylesReady = () => {
  console.log("Site visually ready");
  const tabsGroup = document.querySelector('[data-vfes-js="_tabsGroup"]');
  const tabsGroupMod = new _tab_group_ws10__WEBPACK_IMPORTED_MODULE_1__["default"]({
    $element: tabsGroup
  });
  const cardConvergente = document.querySelector('[data-vfms-js="rateConvergente"]');
  const selectorTabMobile = document.querySelector('[data-vfms-js="buttonTabMobile"]');
  const queryString = window.location.search;
  const urlParams = new URLSearchParams(queryString);
  const customParam = urlParams.get('tv');
  let elemSelectedTab = document.getElementById('vfms-tabs-selected');
  tabsGroupMod.init();
  elemSelectedTab.addEventListener('vfes:changed', event => {
    if (event.index == 1) {
      cardConvergente.classList.remove('vfms-hide');
    } else {
      cardConvergente.classList.add('vfms-hide');
    }
  }); // Mostrar o ocultar tab y card rate según parámetro de url

  if (customParam == 'm') {
    setTimeout(function () {
      selectorTabMobile.click();
    }, 1000);
    cardConvergente.classList.add('vfms-hide');
  } else {
    cardConvergente.classList.remove('vfms-hide');
  }
};
/*
*   Método que se dispara cuando el ws2r.vX.js
*   ya se ha cargado y está diponible.
* */


_tools__WEBPACK_IMPORTED_MODULE_0__["default"].onFrameworkReady = () => {// DO SOMETHING
};

/***/ }),

/***/ "../microsites-cbu/01-particulares/04-tv/tv/home/resources/scripts/tools.js":
/*!**********************************************************************************!*\
  !*** ../microsites-cbu/01-particulares/04-tv/tv/home/resources/scripts/tools.js ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/*
 * Microsites tools js:
 * Este fichero es una muestra de utilidades propias para los microsites.
 * Se puede personalizar a tu gusto
 *
 */
const MICROSITE_ID = '#home';
const cssMain = document.querySelector('link[data-microcss]');
const MICROSITE_SELECTION = closest(document.querySelector(MICROSITE_ID), '[data-pathmicrosite]');
const PATH_MICROSITE = MICROSITE_SELECTION ? MICROSITE_SELECTION.dataset.pathmicrosite : '';
let width = document.documentElement.clientWidth;
let isDesktop = width > 969;
let isTablet = width <= 969 && width >= 768;
let isMobile = width < 768 && width > 300;
/*
 * Searches for the parent node closest to the element, which complies with the selector
 * @param {} el - Description
 * @param {} selector - Description
 * @param {} stopSelector - Description
 * */

function closest(el, selector, stopSelector) {
  let retval = null;

  while (el) {
    if (el.matches(selector)) {
      retval = el;
      break;
    } else if (stopSelector && el.matches(stopSelector)) {
      break;
    }

    el = el.parentElement;
  }

  return retval;
}
/*
 * Removes the style attr, once the stylesheet have been loaded
 * return undefined
 * */


function _internalCSSInit() {
  if (!ex.cssLoaded) {
    document.querySelector(MICROSITE_ID).removeAttribute("style");
    ex.cssLoaded = true;
    ex.onStylesReady();
  }
}
/*
 * Initializes functionality JS, and advices when JS is loaded.
 * return undefined
 * */


function _internalJSInit() {
  window.vfes._utils.init(document.querySelector(MICROSITE_ID));

  ex.onFrameworkReady();
}
/*
 * Check if stylesheet CSS is loaded
 * @return {boolean}
 * */


function isCSSMicroLoaded() {
  const domStyles = document.styleSheets;
  let countCSS = 0;
  [].forEach.call(domStyles, item => {
    const href = item.href || '';

    if (href.indexOf(PATH_MICROSITE + 'css/ws2r') !== -1) {
      console.log('WS2RCSS Loaded');
      countCSS++;
    }

    if (href.indexOf(PATH_MICROSITE + 'css/styles.css') !== -1) {
      console.log('MICROCSS Loaded');
      countCSS++;
    }
  });
  return countCSS === 2;
}

function init() {} // DO SOMETHING

/*
 * listen event, once have been loaded the files CSS
 * */


if (!isCSSMicroLoaded()) {
  cssMain.addEventListener('load', _internalCSSInit); // Make sure microsite gets visible after 3 secs

  setTimeout(_internalCSSInit, 3000);
} else if (isCSSMicroLoaded()) {
  setTimeout(_internalCSSInit, 100);
}
/*
 * listen event, once have been loaded the files JS
 * */


if (window.vfes) {
  setTimeout(_internalJSInit, 100);
} else {
  document.addEventListener('vfes:frameworkReady', _internalJSInit);
}

const ex = {
  isDesktop,
  isTablet,
  isMobile,
  micrositeId: MICROSITE_ID,
  micrositePath: PATH_MICROSITE,
  init: init,
  cssLoaded: false,
  onStylesReady: () => null,
  onFrameworkReady: () => null
};
/* harmony default export */ __webpack_exports__["default"] = (ex);

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4uL21pY3Jvc2l0ZXMtY2J1LzAxLXBhcnRpY3VsYXJlcy8wNC10di90di9ob21lL3Jlc291cmNlcy9zY3JpcHRzL190YWItZ3JvdXAud3MxMC5qcyIsIndlYnBhY2s6Ly8vLi4vbWljcm9zaXRlcy1jYnUvMDEtcGFydGljdWxhcmVzLzA0LXR2L3R2L2hvbWUvcmVzb3VyY2VzL3NjcmlwdHMvbWFpbi5qcyIsIndlYnBhY2s6Ly8vLi4vbWljcm9zaXRlcy1jYnUvMDEtcGFydGljdWxhcmVzLzA0LXR2L3R2L2hvbWUvcmVzb3VyY2VzL3NjcmlwdHMvdG9vbHMuanMiXSwibmFtZXMiOlsiZGVmYXVsdHMiLCIkZWxlbWVudCIsInVuZGVmaW5lZCIsInNlbGVjdG9ycyIsImNsYXNzZXMiLCJ0YWJBY3RpdmUiLCJUYWJHcm91cFdzMTAiLCJjb25zdHJ1Y3RvciIsInByb3BlcnRpZXMiLCJ0YWJDb250YWluZXIiLCJxdWVyeVNlbGVjdG9yIiwidGFic0l0ZW0iLCJxdWVyeVNlbGVjdG9yQWxsIiwib25DaGFuZ2VkIiwiRXZlbnQiLCJhMTF5IiwiZm9yRWFjaCIsInRhYiIsImhhc0F0dHJpYnV0ZSIsImNvbnNvbGUiLCJsb2ciLCJpbml0IiwiYmluZCIsIm1vZCIsImFkZEV2ZW50TGlzdGVuZXIiLCJnZXRBdHRyaWJ1dGUiLCJhY3RpdmVUYWIiLCJnZXRUYWJBY3RpdmUiLCJjbGFzc0xpc3QiLCJyZW1vdmUiLCJzZXRBdHRyaWJ1dGUiLCJjaGlsZHJlbiIsImFkZCIsInRpdGxlIiwiaW5uZXJUZXh0IiwiaW5kZXgiLCJjb250ZW50VGFiIiwiZGlzcGF0Y2hFdmVudCIsInRvb2xzIiwib25TdHlsZXNSZWFkeSIsInRhYnNHcm91cCIsImRvY3VtZW50IiwidGFic0dyb3VwTW9kIiwiY2FyZENvbnZlcmdlbnRlIiwic2VsZWN0b3JUYWJNb2JpbGUiLCJxdWVyeVN0cmluZyIsIndpbmRvdyIsImxvY2F0aW9uIiwic2VhcmNoIiwidXJsUGFyYW1zIiwiVVJMU2VhcmNoUGFyYW1zIiwiY3VzdG9tUGFyYW0iLCJnZXQiLCJlbGVtU2VsZWN0ZWRUYWIiLCJnZXRFbGVtZW50QnlJZCIsImV2ZW50Iiwic2V0VGltZW91dCIsImNsaWNrIiwib25GcmFtZXdvcmtSZWFkeSIsIk1JQ1JPU0lURV9JRCIsImNzc01haW4iLCJNSUNST1NJVEVfU0VMRUNUSU9OIiwiY2xvc2VzdCIsIlBBVEhfTUlDUk9TSVRFIiwiZGF0YXNldCIsInBhdGhtaWNyb3NpdGUiLCJ3aWR0aCIsImRvY3VtZW50RWxlbWVudCIsImNsaWVudFdpZHRoIiwiaXNEZXNrdG9wIiwiaXNUYWJsZXQiLCJpc01vYmlsZSIsImVsIiwic2VsZWN0b3IiLCJzdG9wU2VsZWN0b3IiLCJyZXR2YWwiLCJtYXRjaGVzIiwicGFyZW50RWxlbWVudCIsIl9pbnRlcm5hbENTU0luaXQiLCJleCIsImNzc0xvYWRlZCIsInJlbW92ZUF0dHJpYnV0ZSIsIl9pbnRlcm5hbEpTSW5pdCIsInZmZXMiLCJfdXRpbHMiLCJpc0NTU01pY3JvTG9hZGVkIiwiZG9tU3R5bGVzIiwic3R5bGVTaGVldHMiLCJjb3VudENTUyIsImNhbGwiLCJpdGVtIiwiaHJlZiIsImluZGV4T2YiLCJtaWNyb3NpdGVJZCIsIm1pY3Jvc2l0ZVBhdGgiXSwibWFwcGluZ3MiOiI7UUFBQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTs7O1FBR0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDBDQUEwQyxnQ0FBZ0M7UUFDMUU7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSx3REFBd0Qsa0JBQWtCO1FBQzFFO1FBQ0EsaURBQWlELGNBQWM7UUFDL0Q7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLHlDQUF5QyxpQ0FBaUM7UUFDMUUsZ0hBQWdILG1CQUFtQixFQUFFO1FBQ3JJO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMkJBQTJCLDBCQUEwQixFQUFFO1FBQ3ZELGlDQUFpQyxlQUFlO1FBQ2hEO1FBQ0E7UUFDQTs7UUFFQTtRQUNBLHNEQUFzRCwrREFBK0Q7O1FBRXJIO1FBQ0E7OztRQUdBO1FBQ0E7Ozs7Ozs7Ozs7Ozs7QUNsRkE7QUFBQTtBQUFBLE1BQU1BLFFBQVEsR0FBRztBQUNiQyxVQUFRLEVBQUVDLFNBREc7QUFFYkMsV0FBUyxFQUFFLEVBRkU7QUFJYkMsU0FBTyxFQUFFO0FBQ0xDLGFBQVMsRUFBRztBQURQO0FBSkksQ0FBakI7QUFTQTs7Ozs7Ozs7QUFPZSxNQUFNQyxZQUFOLENBQW1CO0FBQzlCQyxhQUFXLENBQUNDLFVBQVUsR0FBRyxFQUFkLEVBQWtCO0FBQ3pCLFNBQUtQLFFBQUwsR0FBZ0JPLFVBQVUsQ0FBQ1AsUUFBM0I7QUFDQSxTQUFLRSxTQUFMLEdBQWlCSCxRQUFRLENBQUNHLFNBQTFCO0FBQ0EsU0FBS0MsT0FBTCxHQUFlSixRQUFRLENBQUNJLE9BQXhCO0FBQ0EsU0FBS0ssWUFBTCxHQUFvQixLQUFLUixRQUFMLENBQWNTLGFBQWQsQ0FBNkIsNEJBQTdCLENBQXBCO0FBQ0EsU0FBS0MsUUFBTCxHQUFnQixLQUFLRixZQUFMLENBQWtCRyxnQkFBbEIsQ0FBb0MsY0FBcEMsQ0FBaEI7QUFDQSxTQUFLQyxTQUFMLEdBQWlCLElBQUlDLEtBQUosQ0FBVSxjQUFWLENBQWpCO0FBQ0g7O0FBRURDLE1BQUksR0FBRztBQUNILEtBQUMsR0FBRyxLQUFLSixRQUFULEVBQW1CSyxPQUFuQixDQUEyQkMsR0FBRyxJQUFJO0FBQzlCLFVBQUcsQ0FBQ0EsR0FBRyxDQUFDQyxZQUFKLENBQWlCLE1BQWpCLENBQUQsS0FBOEIsS0FBOUIsSUFDSSxDQUFDRCxHQUFHLENBQUNDLFlBQUosQ0FBaUIsYUFBakIsQ0FEUixFQUN5QztBQUNyQ0MsZUFBTyxDQUFDQyxHQUFSLENBQVksMkpBQVo7QUFDSDtBQUNKLEtBTEQ7QUFNSDtBQUVEOzs7Ozs7Ozs7QUFPQUMsTUFBSSxHQUFHO0FBQ0gsU0FBS0MsSUFBTDtBQUNBLFNBQUtQLElBQUw7QUFDSDtBQUVEOzs7Ozs7Ozs7O0FBUUFPLE1BQUksR0FBRztBQUNILFVBQU1DLEdBQUcsR0FBRyxJQUFaO0FBRUEsS0FBQyxHQUFHQSxHQUFHLENBQUNaLFFBQVIsRUFBa0JLLE9BQWxCLENBQTBCQyxHQUFHLElBQUk7QUFDN0JBLFNBQUcsQ0FBQ08sZ0JBQUosQ0FBcUIsT0FBckIsRUFBOEIsTUFBTTtBQUNoQyxZQUFHUCxHQUFHLENBQUNRLFlBQUosQ0FBaUIsaUJBQWpCLE1BQXdDLE9BQTNDLEVBQW9EO0FBQ2hELGNBQUlDLFNBQVMsR0FBR0gsR0FBRyxDQUFDSSxZQUFKLEVBQWhCLENBRGdELENBR2hEOztBQUNBRCxtQkFBUyxDQUFDRSxTQUFWLENBQW9CQyxNQUFwQixDQUEyQk4sR0FBRyxDQUFDbkIsT0FBSixDQUFZQyxTQUF2QztBQUNBcUIsbUJBQVMsQ0FBQ0ksWUFBVixDQUF1QixpQkFBdkIsRUFBMEMsT0FBMUM7QUFDQVAsYUFBRyxDQUFDdEIsUUFBSixDQUFhOEIsUUFBYixDQUFzQkwsU0FBUyxDQUFDRCxZQUFWLENBQXVCLGVBQXZCLENBQXRCLEVBQStESyxZQUEvRCxDQUE0RSxlQUE1RSxFQUE2RixPQUE3RixFQU5nRCxDQVFoRDs7QUFDQWIsYUFBRyxDQUFDVyxTQUFKLENBQWNJLEdBQWQsQ0FBa0JULEdBQUcsQ0FBQ25CLE9BQUosQ0FBWUMsU0FBOUI7QUFDQVksYUFBRyxDQUFDYSxZQUFKLENBQWlCLGlCQUFqQixFQUFvQyxNQUFwQztBQUNBUCxhQUFHLENBQUN0QixRQUFKLENBQWE4QixRQUFiLENBQXNCZCxHQUFHLENBQUNRLFlBQUosQ0FBaUIsZUFBakIsQ0FBdEIsRUFBeURLLFlBQXpELENBQXNFLGVBQXRFLEVBQXVGLE1BQXZGO0FBRUFQLGFBQUcsQ0FBQ1YsU0FBSixDQUFjSSxHQUFkLEdBQW9CQSxHQUFwQjtBQUNBTSxhQUFHLENBQUNWLFNBQUosQ0FBY29CLEtBQWQsR0FBc0JoQixHQUFHLENBQUNpQixTQUExQjtBQUNBWCxhQUFHLENBQUNWLFNBQUosQ0FBY3NCLEtBQWQsR0FBc0JsQixHQUFHLENBQUNRLFlBQUosQ0FBaUIsYUFBakIsQ0FBdEI7QUFDQUYsYUFBRyxDQUFDVixTQUFKLENBQWN1QixVQUFkLEdBQTJCYixHQUFHLENBQUN0QixRQUFKLENBQWFTLGFBQWIsQ0FBNEIsd0JBQTVCLENBQTNCO0FBQ0FhLGFBQUcsQ0FBQ3RCLFFBQUosQ0FBYW9DLGFBQWIsQ0FBMkJkLEdBQUcsQ0FBQ1YsU0FBL0I7QUFDSDtBQUNKLE9BcEJEO0FBcUJILEtBdEJEO0FBd0JBLFNBQUtKLFlBQUwsQ0FBa0JlLGdCQUFsQixDQUFtQyxPQUFuQyxFQUE0QyxNQUFNO0FBQzlDLFdBQUtmLFlBQUwsQ0FBa0JnQixZQUFsQixDQUErQixlQUEvQixNQUFvRCxPQUFwRCxHQUE4RCxLQUFLaEIsWUFBTCxDQUFrQnFCLFlBQWxCLENBQStCLGVBQS9CLEVBQWdELE1BQWhELENBQTlELEdBQXdILEtBQUtyQixZQUFMLENBQWtCcUIsWUFBbEIsQ0FBK0IsZUFBL0IsRUFBZ0QsT0FBaEQsQ0FBeEg7QUFDSCxLQUZEO0FBR0g7O0FBRURILGNBQVksR0FBRztBQUNYLFdBQU8sS0FBS2xCLFlBQUwsQ0FBa0JDLGFBQWxCLENBQWlDLDBCQUFqQyxDQUFQO0FBQ0g7O0FBekU2QixDOzs7Ozs7Ozs7Ozs7QUNoQmxDO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFHQTs7Ozs7QUFJQTRCLDhDQUFLLENBQUNDLGFBQU4sR0FBc0IsTUFBTTtBQUN4QnBCLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLHFCQUFaO0FBRUEsUUFBTW9CLFNBQVMsR0FBR0MsUUFBUSxDQUFDL0IsYUFBVCxDQUF1Qiw2QkFBdkIsQ0FBbEI7QUFDQSxRQUFNZ0MsWUFBWSxHQUFHLElBQUlwQyx1REFBSixDQUFpQjtBQUFDTCxZQUFRLEVBQUV1QztBQUFYLEdBQWpCLENBQXJCO0FBRUEsUUFBTUcsZUFBZSxHQUFHRixRQUFRLENBQUMvQixhQUFULENBQXVCLGtDQUF2QixDQUF4QjtBQUNBLFFBQU1rQyxpQkFBaUIsR0FBR0gsUUFBUSxDQUFDL0IsYUFBVCxDQUF1QixrQ0FBdkIsQ0FBMUI7QUFDQSxRQUFNbUMsV0FBVyxHQUFHQyxNQUFNLENBQUNDLFFBQVAsQ0FBZ0JDLE1BQXBDO0FBQ0EsUUFBTUMsU0FBUyxHQUFHLElBQUlDLGVBQUosQ0FBb0JMLFdBQXBCLENBQWxCO0FBQ0EsUUFBTU0sV0FBVyxHQUFHRixTQUFTLENBQUNHLEdBQVYsQ0FBYyxJQUFkLENBQXBCO0FBRUEsTUFBSUMsZUFBZSxHQUFHWixRQUFRLENBQUNhLGNBQVQsQ0FBd0Isb0JBQXhCLENBQXRCO0FBRUFaLGNBQVksQ0FBQ3JCLElBQWI7QUFFQWdDLGlCQUFlLENBQUM3QixnQkFBaEIsQ0FBaUMsY0FBakMsRUFBa0QrQixLQUFELElBQVc7QUFFeEQsUUFBR0EsS0FBSyxDQUFDcEIsS0FBTixJQUFhLENBQWhCLEVBQWtCO0FBQ2RRLHFCQUFlLENBQUNmLFNBQWhCLENBQTBCQyxNQUExQixDQUFpQyxXQUFqQztBQUNILEtBRkQsTUFHSTtBQUNBYyxxQkFBZSxDQUFDZixTQUFoQixDQUEwQkksR0FBMUIsQ0FBOEIsV0FBOUI7QUFDSDtBQUdKLEdBVkQsRUFoQndCLENBNEJ4Qjs7QUFFQSxNQUFJbUIsV0FBVyxJQUFHLEdBQWxCLEVBQXNCO0FBQ2xCSyxjQUFVLENBQUMsWUFBVTtBQUFFWix1QkFBaUIsQ0FBQ2EsS0FBbEI7QUFBNEIsS0FBekMsRUFBMkMsSUFBM0MsQ0FBVjtBQUNBZCxtQkFBZSxDQUFDZixTQUFoQixDQUEwQkksR0FBMUIsQ0FBOEIsV0FBOUI7QUFDSCxHQUhELE1BSUk7QUFDQVcsbUJBQWUsQ0FBQ2YsU0FBaEIsQ0FBMEJDLE1BQTFCLENBQWlDLFdBQWpDO0FBQ0g7QUFHSixDQXZDRDtBQTBDQTs7Ozs7O0FBTUFTLDhDQUFLLENBQUNvQixnQkFBTixHQUF5QixNQUFNLENBQy9CO0FBRUMsQ0FIRCxDOzs7Ozs7Ozs7Ozs7QUN4REE7QUFBQTs7Ozs7O0FBUUEsTUFBTUMsWUFBWSxHQUFHLE9BQXJCO0FBQ0EsTUFBTUMsT0FBTyxHQUFHbkIsUUFBUSxDQUFDL0IsYUFBVCxDQUF1QixxQkFBdkIsQ0FBaEI7QUFDQSxNQUFNbUQsbUJBQW1CLEdBQUdDLE9BQU8sQ0FBQ3JCLFFBQVEsQ0FBQy9CLGFBQVQsQ0FBdUJpRCxZQUF2QixDQUFELEVBQXVDLHNCQUF2QyxDQUFuQztBQUNBLE1BQU1JLGNBQWMsR0FBR0YsbUJBQW1CLEdBQUdBLG1CQUFtQixDQUFDRyxPQUFwQixDQUE0QkMsYUFBL0IsR0FBK0MsRUFBekY7QUFDQSxJQUFJQyxLQUFLLEdBQUd6QixRQUFRLENBQUMwQixlQUFULENBQXlCQyxXQUFyQztBQUNBLElBQUlDLFNBQVMsR0FBR0gsS0FBSyxHQUFHLEdBQXhCO0FBQ0EsSUFBSUksUUFBUSxHQUFHSixLQUFLLElBQUksR0FBVCxJQUFnQkEsS0FBSyxJQUFJLEdBQXhDO0FBQ0EsSUFBSUssUUFBUSxHQUFHTCxLQUFLLEdBQUcsR0FBUixJQUFlQSxLQUFLLEdBQUcsR0FBdEM7QUFHQTs7Ozs7OztBQU1BLFNBQVNKLE9BQVQsQ0FBaUJVLEVBQWpCLEVBQXFCQyxRQUFyQixFQUErQkMsWUFBL0IsRUFBNkM7QUFDekMsTUFBSUMsTUFBTSxHQUFHLElBQWI7O0FBQ0EsU0FBT0gsRUFBUCxFQUFXO0FBQ1AsUUFBSUEsRUFBRSxDQUFDSSxPQUFILENBQVdILFFBQVgsQ0FBSixFQUEwQjtBQUN0QkUsWUFBTSxHQUFHSCxFQUFUO0FBQ0E7QUFDSCxLQUhELE1BR08sSUFBSUUsWUFBWSxJQUFJRixFQUFFLENBQUNJLE9BQUgsQ0FBV0YsWUFBWCxDQUFwQixFQUE4QztBQUNqRDtBQUNIOztBQUNERixNQUFFLEdBQUdBLEVBQUUsQ0FBQ0ssYUFBUjtBQUNIOztBQUNELFNBQU9GLE1BQVA7QUFDSDtBQUdEOzs7Ozs7QUFJQSxTQUFTRyxnQkFBVCxHQUE0QjtBQUN4QixNQUFHLENBQUNDLEVBQUUsQ0FBQ0MsU0FBUCxFQUFpQjtBQUNidkMsWUFBUSxDQUFDL0IsYUFBVCxDQUF1QmlELFlBQXZCLEVBQXFDc0IsZUFBckMsQ0FBcUQsT0FBckQ7QUFDQUYsTUFBRSxDQUFDQyxTQUFILEdBQWUsSUFBZjtBQUNBRCxNQUFFLENBQUN4QyxhQUFIO0FBQ0g7QUFDSjtBQUdEOzs7Ozs7QUFJQSxTQUFTMkMsZUFBVCxHQUEyQjtBQUN2QnBDLFFBQU0sQ0FBQ3FDLElBQVAsQ0FBWUMsTUFBWixDQUFtQi9ELElBQW5CLENBQXdCb0IsUUFBUSxDQUFDL0IsYUFBVCxDQUF1QmlELFlBQXZCLENBQXhCOztBQUNBb0IsSUFBRSxDQUFDckIsZ0JBQUg7QUFDSDtBQUdEOzs7Ozs7QUFJQSxTQUFTMkIsZ0JBQVQsR0FBNEI7QUFDeEIsUUFBTUMsU0FBUyxHQUFHN0MsUUFBUSxDQUFDOEMsV0FBM0I7QUFDQSxNQUFJQyxRQUFRLEdBQUcsQ0FBZjtBQUNBLEtBQUd4RSxPQUFILENBQVd5RSxJQUFYLENBQWdCSCxTQUFoQixFQUE0QkksSUFBRCxJQUFVO0FBQ2pDLFVBQU1DLElBQUksR0FBR0QsSUFBSSxDQUFDQyxJQUFMLElBQWEsRUFBMUI7O0FBQ0EsUUFBSUEsSUFBSSxDQUFDQyxPQUFMLENBQWE3QixjQUFjLEdBQUcsVUFBOUIsTUFBOEMsQ0FBQyxDQUFuRCxFQUFzRDtBQUNsRDVDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGdCQUFaO0FBQ0FvRSxjQUFRO0FBQ1g7O0FBQ0QsUUFBSUcsSUFBSSxDQUFDQyxPQUFMLENBQWE3QixjQUFjLEdBQUcsZ0JBQTlCLE1BQW9ELENBQUMsQ0FBekQsRUFBNEQ7QUFDeEQ1QyxhQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWjtBQUNBb0UsY0FBUTtBQUNYO0FBQ0osR0FWRDtBQVdBLFNBQVFBLFFBQVEsS0FBSyxDQUFyQjtBQUNIOztBQUdELFNBQVNuRSxJQUFULEdBQWdCLENBRWYsQ0FGRCxDQUNJOztBQUdKOzs7OztBQUdBLElBQUksQ0FBQ2dFLGdCQUFnQixFQUFyQixFQUF5QjtBQUNyQnpCLFNBQU8sQ0FBQ3BDLGdCQUFSLENBQXlCLE1BQXpCLEVBQWlDc0QsZ0JBQWpDLEVBRHFCLENBRXJCOztBQUNBdEIsWUFBVSxDQUFDc0IsZ0JBQUQsRUFBbUIsSUFBbkIsQ0FBVjtBQUNILENBSkQsTUFJTyxJQUFJTyxnQkFBZ0IsRUFBcEIsRUFBd0I7QUFDM0I3QixZQUFVLENBQUNzQixnQkFBRCxFQUFtQixHQUFuQixDQUFWO0FBQ0g7QUFHRDs7Ozs7QUFHQSxJQUFJaEMsTUFBTSxDQUFDcUMsSUFBWCxFQUFpQjtBQUNiM0IsWUFBVSxDQUFDMEIsZUFBRCxFQUFrQixHQUFsQixDQUFWO0FBQ0gsQ0FGRCxNQUVPO0FBQ0h6QyxVQUFRLENBQUNqQixnQkFBVCxDQUEwQixxQkFBMUIsRUFBaUQwRCxlQUFqRDtBQUNIOztBQUVELE1BQU1ILEVBQUUsR0FBRztBQUNQVixXQURPO0FBRVBDLFVBRk87QUFHUEMsVUFITztBQUlQc0IsYUFBVyxFQUFFbEMsWUFKTjtBQUtQbUMsZUFBYSxFQUFFL0IsY0FMUjtBQU1QMUMsTUFBSSxFQUFFQSxJQU5DO0FBT1AyRCxXQUFTLEVBQUUsS0FQSjtBQVFQekMsZUFBYSxFQUFFLE1BQU0sSUFSZDtBQVNQbUIsa0JBQWdCLEVBQUUsTUFBTTtBQVRqQixDQUFYO0FBWWVxQixpRUFBZixFIiwiZmlsZSI6Im1haW4uanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gXCIuLi9taWNyb3NpdGVzLWNidS8wMS1wYXJ0aWN1bGFyZXMvMDQtdHYvdHYvaG9tZS9yZXNvdXJjZXMvc2NyaXB0cy9tYWluLmpzXCIpO1xuIiwiY29uc3QgZGVmYXVsdHMgPSB7XHJcbiAgICAkZWxlbWVudDogdW5kZWZpbmVkLFxyXG4gICAgc2VsZWN0b3JzOiB7XHJcbiAgICB9LFxyXG4gICAgY2xhc3Nlczoge1xyXG4gICAgICAgIHRhYkFjdGl2ZTogYHZmZXMtdGFiLWdyb3VwX19jb250YWluZXItaXRlbS0tYWN0aXZlYFxyXG4gICAgfVxyXG59O1xyXG5cclxuLyoqXHJcbiAqIFRhYnMuXHJcbiAqXHJcbiAqIEBtb2R1bGUgVGFiR3JvdXBXczEwXHJcbiAqIEBwYXJhbSB7T2JqZWN0fSBwcm9wZXJ0aWVzIC0gc3BlY2lmaWVzIHRoZSBjb25maWd1cmF0aW9uc1xyXG4gKiBmb3IgdGhlIG1vZHVsZS5cclxuICovXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFRhYkdyb3VwV3MxMCB7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcm9wZXJ0aWVzID0ge30pIHtcclxuICAgICAgICB0aGlzLiRlbGVtZW50ID0gcHJvcGVydGllcy4kZWxlbWVudDtcclxuICAgICAgICB0aGlzLnNlbGVjdG9ycyA9IGRlZmF1bHRzLnNlbGVjdG9ycztcclxuICAgICAgICB0aGlzLmNsYXNzZXMgPSBkZWZhdWx0cy5jbGFzc2VzO1xyXG4gICAgICAgIHRoaXMudGFiQ29udGFpbmVyID0gdGhpcy4kZWxlbWVudC5xdWVyeVNlbGVjdG9yKGBbZGF0YS10YWI9XCJ0YWItY29udGFpbmVyXCJdYCk7XHJcbiAgICAgICAgdGhpcy50YWJzSXRlbSA9IHRoaXMudGFiQ29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGwoYFtyb2xlPVwidGFiXCJdYCk7XHJcbiAgICAgICAgdGhpcy5vbkNoYW5nZWQgPSBuZXcgRXZlbnQoJ3ZmZXM6Y2hhbmdlZCcpO1xyXG4gICAgfVxyXG5cclxuICAgIGExMXkoKSB7XHJcbiAgICAgICAgWy4uLnRoaXMudGFic0l0ZW1dLmZvckVhY2godGFiID0+IHtcclxuICAgICAgICAgICAgaWYoIXRhYi5oYXNBdHRyaWJ1dGUoXCJyb2xlXCIpID09PSBcInRhYlwiXHJcbiAgICAgICAgICAgICAgICB8fCAhdGFiLmhhc0F0dHJpYnV0ZShcImRhdGEtb3B0aW9uXCIpKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnTGFzIHRhYnMgZ3JvdXAgdGllbmVuIHF1ZSB0ZW5lciBsb3MgYXRyaWJ1dG9zOiBcInJvbGVcIiBjb24gZWwgdmFsb3IgZGUgdGFiLCBcImFyaWEtc2VsZWN0ZWRcIiBjb24gdW4gdmFsb3IgdHJ1ZSBvIGZhbHNlLCBcImRhdGEtb3B0aW9uXCIgY29uIHVuIHZhbG9yIG51bcOpcmljbycpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBJbml0aWFsaXNlIHRoZSBtb2R1bGUuXHJcbiAgICAgKlxyXG4gICAgICogQGZ1bmN0aW9uIGluaXRcclxuICAgICAqXHJcbiAgICAgKiBAcmV0dXJuIHVuZGVmaW5lZFxyXG4gICAgICovXHJcbiAgICBpbml0KCkge1xyXG4gICAgICAgIHRoaXMuYmluZCgpO1xyXG4gICAgICAgIHRoaXMuYTExeSgpO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICAvKipcclxuICAgICAqIEJpbmQgdGhlIGV2ZW50cyB0byB0aGUgYWN0aW9uYWJsZSBlbGVtZW50c1xyXG4gICAgICogd2l0aGluIHRoZSB0YWJzIHN5c3RlbS5cclxuICAgICAqXHJcbiAgICAgKiBAZnVuY3Rpb24gYmluZFxyXG4gICAgICpcclxuICAgICAqIEByZXR1cm4gdW5kZWZpbmVkXHJcbiAgICAgKi9cclxuICAgIGJpbmQoKSB7XHJcbiAgICAgICAgY29uc3QgbW9kID0gdGhpcztcclxuICAgICAgICBcclxuICAgICAgICBbLi4ubW9kLnRhYnNJdGVtXS5mb3JFYWNoKHRhYiA9PiB7XHJcbiAgICAgICAgICAgIHRhYi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmKHRhYi5nZXRBdHRyaWJ1dGUoJ2RhdGEtdGFiLWFjdGl2ZScpID09PSAnZmFsc2UnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGFjdGl2ZVRhYiA9IG1vZC5nZXRUYWJBY3RpdmUoKTtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAvLyBQZXN0YcOxYSBhY3R1YWwgYWN0aXZhZGFcclxuICAgICAgICAgICAgICAgICAgICBhY3RpdmVUYWIuY2xhc3NMaXN0LnJlbW92ZShtb2QuY2xhc3Nlcy50YWJBY3RpdmUpO1xyXG4gICAgICAgICAgICAgICAgICAgIGFjdGl2ZVRhYi5zZXRBdHRyaWJ1dGUoJ2RhdGEtdGFiLWFjdGl2ZScsICdmYWxzZScpO1xyXG4gICAgICAgICAgICAgICAgICAgIG1vZC4kZWxlbWVudC5jaGlsZHJlblthY3RpdmVUYWIuZ2V0QXR0cmlidXRlKCdhcmlhLWNvbnRyb2xzJyldLnNldEF0dHJpYnV0ZSgnYXJpYS1leHBhbmRlZCcsICdmYWxzZScpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAvLyBOdWV2YSBwZXN0YcOxYSBhIGFjdGl2YXJcclxuICAgICAgICAgICAgICAgICAgICB0YWIuY2xhc3NMaXN0LmFkZChtb2QuY2xhc3Nlcy50YWJBY3RpdmUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRhYi5zZXRBdHRyaWJ1dGUoJ2RhdGEtdGFiLWFjdGl2ZScsICd0cnVlJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgbW9kLiRlbGVtZW50LmNoaWxkcmVuW3RhYi5nZXRBdHRyaWJ1dGUoJ2FyaWEtY29udHJvbHMnKV0uc2V0QXR0cmlidXRlKCdhcmlhLWV4cGFuZGVkJywgJ3RydWUnKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgbW9kLm9uQ2hhbmdlZC50YWIgPSB0YWI7XHJcbiAgICAgICAgICAgICAgICAgICAgbW9kLm9uQ2hhbmdlZC50aXRsZSA9IHRhYi5pbm5lclRleHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgbW9kLm9uQ2hhbmdlZC5pbmRleCA9IHRhYi5nZXRBdHRyaWJ1dGUoJ2RhdGEtb3B0aW9uJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgbW9kLm9uQ2hhbmdlZC5jb250ZW50VGFiID0gbW9kLiRlbGVtZW50LnF1ZXJ5U2VsZWN0b3IoYFthcmlhLWV4cGFuZGVkPVwidHJ1ZVwiXWApO1xyXG4gICAgICAgICAgICAgICAgICAgIG1vZC4kZWxlbWVudC5kaXNwYXRjaEV2ZW50KG1vZC5vbkNoYW5nZWQpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy50YWJDb250YWluZXIuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMudGFiQ29udGFpbmVyLmdldEF0dHJpYnV0ZSgnYXJpYS1leHBhbmRlZCcpID09PSAnZmFsc2UnID8gdGhpcy50YWJDb250YWluZXIuc2V0QXR0cmlidXRlKCdhcmlhLWV4cGFuZGVkJywgJ3RydWUnKSA6IHRoaXMudGFiQ29udGFpbmVyLnNldEF0dHJpYnV0ZSgnYXJpYS1leHBhbmRlZCcsICdmYWxzZScpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIGdldFRhYkFjdGl2ZSgpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy50YWJDb250YWluZXIucXVlcnlTZWxlY3RvcihgW2RhdGEtdGFiLWFjdGl2ZT1cInRydWVcIl1gKTtcclxuICAgIH1cclxufVxyXG4iLCJpbXBvcnQgdG9vbHMgZnJvbSAnLi90b29scyc7XG5pbXBvcnQgVGFiR3JvdXBXczEwIGZyb20gJy4vX3RhYi1ncm91cC53czEwJztcblxuXG4vKlxuKiAgIE3DqXRvZG8gcXVlIHNlIGRpc3BhcmEgY3VhbmRvIGVsIHdzMnIudlguY3NzXG4qICAgeWEgc2UgaGEgY2FyZ2FkbyB5IGhhIHBpbnRhZG8gbGEgd2ViXG4qICovXG50b29scy5vblN0eWxlc1JlYWR5ID0gKCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKFwiU2l0ZSB2aXN1YWxseSByZWFkeVwiKTtcblxuICAgIGNvbnN0IHRhYnNHcm91cCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ1tkYXRhLXZmZXMtanM9XCJfdGFic0dyb3VwXCJdJyk7XG4gICAgY29uc3QgdGFic0dyb3VwTW9kID0gbmV3IFRhYkdyb3VwV3MxMCh7JGVsZW1lbnQ6IHRhYnNHcm91cH0pO1xuXG4gICAgY29uc3QgY2FyZENvbnZlcmdlbnRlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignW2RhdGEtdmZtcy1qcz1cInJhdGVDb252ZXJnZW50ZVwiXScpO1xuICAgIGNvbnN0IHNlbGVjdG9yVGFiTW9iaWxlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignW2RhdGEtdmZtcy1qcz1cImJ1dHRvblRhYk1vYmlsZVwiXScpO1xuICAgIGNvbnN0IHF1ZXJ5U3RyaW5nID0gd2luZG93LmxvY2F0aW9uLnNlYXJjaDtcbiAgICBjb25zdCB1cmxQYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHF1ZXJ5U3RyaW5nKTtcbiAgICBjb25zdCBjdXN0b21QYXJhbSA9IHVybFBhcmFtcy5nZXQoJ3R2Jyk7XG5cbiAgICBsZXQgZWxlbVNlbGVjdGVkVGFiID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3ZmbXMtdGFicy1zZWxlY3RlZCcpO1xuXG4gICAgdGFic0dyb3VwTW9kLmluaXQoKTtcblxuICAgIGVsZW1TZWxlY3RlZFRhYi5hZGRFdmVudExpc3RlbmVyKCd2ZmVzOmNoYW5nZWQnLCAoZXZlbnQpID0+IHtcblxuICAgICAgICBpZihldmVudC5pbmRleD09MSl7XG4gICAgICAgICAgICBjYXJkQ29udmVyZ2VudGUuY2xhc3NMaXN0LnJlbW92ZSgndmZtcy1oaWRlJyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIGNhcmRDb252ZXJnZW50ZS5jbGFzc0xpc3QuYWRkKCd2Zm1zLWhpZGUnKTtcbiAgICAgICAgfVxuXG5cbiAgICB9KTtcblxuICAgIC8vIE1vc3RyYXIgbyBvY3VsdGFyIHRhYiB5IGNhcmQgcmF0ZSBzZWfDum4gcGFyw6FtZXRybyBkZSB1cmxcblxuICAgIGlmIChjdXN0b21QYXJhbSA9PSdtJyl7XG4gICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKXsgc2VsZWN0b3JUYWJNb2JpbGUuY2xpY2soKTsgfSwgMTAwMCk7XG4gICAgICAgIGNhcmRDb252ZXJnZW50ZS5jbGFzc0xpc3QuYWRkKCd2Zm1zLWhpZGUnKTtcbiAgICB9XG4gICAgZWxzZXtcbiAgICAgICAgY2FyZENvbnZlcmdlbnRlLmNsYXNzTGlzdC5yZW1vdmUoJ3ZmbXMtaGlkZScpO1xuICAgIH1cblxuXG59O1xuXG5cbi8qXG4qICAgTcOpdG9kbyBxdWUgc2UgZGlzcGFyYSBjdWFuZG8gZWwgd3Myci52WC5qc1xuKiAgIHlhIHNlIGhhIGNhcmdhZG8geSBlc3TDoSBkaXBvbmlibGUuXG4qICovXG5cblxudG9vbHMub25GcmFtZXdvcmtSZWFkeSA9ICgpID0+IHtcbi8vIERPIFNPTUVUSElOR1xuXG59O1xuXG4iLCIvKlxuICogTWljcm9zaXRlcyB0b29scyBqczpcbiAqIEVzdGUgZmljaGVybyBlcyB1bmEgbXVlc3RyYSBkZSB1dGlsaWRhZGVzIHByb3BpYXMgcGFyYSBsb3MgbWljcm9zaXRlcy5cbiAqIFNlIHB1ZWRlIHBlcnNvbmFsaXphciBhIHR1IGd1c3RvXG4gKlxuICovXG5cblxuY29uc3QgTUlDUk9TSVRFX0lEID0gJyNob21lJztcbmNvbnN0IGNzc01haW4gPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdsaW5rW2RhdGEtbWljcm9jc3NdJyk7XG5jb25zdCBNSUNST1NJVEVfU0VMRUNUSU9OID0gY2xvc2VzdChkb2N1bWVudC5xdWVyeVNlbGVjdG9yKE1JQ1JPU0lURV9JRCksICdbZGF0YS1wYXRobWljcm9zaXRlXScpO1xuY29uc3QgUEFUSF9NSUNST1NJVEUgPSBNSUNST1NJVEVfU0VMRUNUSU9OID8gTUlDUk9TSVRFX1NFTEVDVElPTi5kYXRhc2V0LnBhdGhtaWNyb3NpdGUgOiAnJztcbmxldCB3aWR0aCA9IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGllbnRXaWR0aDtcbmxldCBpc0Rlc2t0b3AgPSB3aWR0aCA+IDk2OTtcbmxldCBpc1RhYmxldCA9IHdpZHRoIDw9IDk2OSAmJiB3aWR0aCA+PSA3Njg7XG5sZXQgaXNNb2JpbGUgPSB3aWR0aCA8IDc2OCAmJiB3aWR0aCA+IDMwMDtcblxuXG4vKlxuICogU2VhcmNoZXMgZm9yIHRoZSBwYXJlbnQgbm9kZSBjbG9zZXN0IHRvIHRoZSBlbGVtZW50LCB3aGljaCBjb21wbGllcyB3aXRoIHRoZSBzZWxlY3RvclxuICogQHBhcmFtIHt9IGVsIC0gRGVzY3JpcHRpb25cbiAqIEBwYXJhbSB7fSBzZWxlY3RvciAtIERlc2NyaXB0aW9uXG4gKiBAcGFyYW0ge30gc3RvcFNlbGVjdG9yIC0gRGVzY3JpcHRpb25cbiAqICovXG5mdW5jdGlvbiBjbG9zZXN0KGVsLCBzZWxlY3Rvciwgc3RvcFNlbGVjdG9yKSB7XG4gICAgbGV0IHJldHZhbCA9IG51bGw7XG4gICAgd2hpbGUgKGVsKSB7XG4gICAgICAgIGlmIChlbC5tYXRjaGVzKHNlbGVjdG9yKSkge1xuICAgICAgICAgICAgcmV0dmFsID0gZWw7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfSBlbHNlIGlmIChzdG9wU2VsZWN0b3IgJiYgZWwubWF0Y2hlcyhzdG9wU2VsZWN0b3IpKSB7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBlbCA9IGVsLnBhcmVudEVsZW1lbnQ7XG4gICAgfVxuICAgIHJldHVybiByZXR2YWw7XG59XG5cblxuLypcbiAqIFJlbW92ZXMgdGhlIHN0eWxlIGF0dHIsIG9uY2UgdGhlIHN0eWxlc2hlZXQgaGF2ZSBiZWVuIGxvYWRlZFxuICogcmV0dXJuIHVuZGVmaW5lZFxuICogKi9cbmZ1bmN0aW9uIF9pbnRlcm5hbENTU0luaXQoKSB7XG4gICAgaWYoIWV4LmNzc0xvYWRlZCl7XG4gICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoTUlDUk9TSVRFX0lEKS5yZW1vdmVBdHRyaWJ1dGUoXCJzdHlsZVwiKTtcbiAgICAgICAgZXguY3NzTG9hZGVkID0gdHJ1ZTtcbiAgICAgICAgZXgub25TdHlsZXNSZWFkeSgpO1xuICAgIH1cbn1cblxuXG4vKlxuICogSW5pdGlhbGl6ZXMgZnVuY3Rpb25hbGl0eSBKUywgYW5kIGFkdmljZXMgd2hlbiBKUyBpcyBsb2FkZWQuXG4gKiByZXR1cm4gdW5kZWZpbmVkXG4gKiAqL1xuZnVuY3Rpb24gX2ludGVybmFsSlNJbml0KCkge1xuICAgIHdpbmRvdy52ZmVzLl91dGlscy5pbml0KGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoTUlDUk9TSVRFX0lEKSk7XG4gICAgZXgub25GcmFtZXdvcmtSZWFkeSgpO1xufVxuXG5cbi8qXG4gKiBDaGVjayBpZiBzdHlsZXNoZWV0IENTUyBpcyBsb2FkZWRcbiAqIEByZXR1cm4ge2Jvb2xlYW59XG4gKiAqL1xuZnVuY3Rpb24gaXNDU1NNaWNyb0xvYWRlZCgpIHtcbiAgICBjb25zdCBkb21TdHlsZXMgPSBkb2N1bWVudC5zdHlsZVNoZWV0cztcbiAgICBsZXQgY291bnRDU1MgPSAwO1xuICAgIFtdLmZvckVhY2guY2FsbChkb21TdHlsZXMsIChpdGVtKSA9PiB7XG4gICAgICAgIGNvbnN0IGhyZWYgPSBpdGVtLmhyZWYgfHwgJyc7XG4gICAgICAgIGlmIChocmVmLmluZGV4T2YoUEFUSF9NSUNST1NJVEUgKyAnY3NzL3dzMnInKSAhPT0gLTEpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdXUzJSQ1NTIExvYWRlZCcpO1xuICAgICAgICAgICAgY291bnRDU1MrKztcbiAgICAgICAgfVxuICAgICAgICBpZiAoaHJlZi5pbmRleE9mKFBBVEhfTUlDUk9TSVRFICsgJ2Nzcy9zdHlsZXMuY3NzJykgIT09IC0xKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnTUlDUk9DU1MgTG9hZGVkJyk7XG4gICAgICAgICAgICBjb3VudENTUysrXG4gICAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gKGNvdW50Q1NTID09PSAyKTtcbn1cblxuXG5mdW5jdGlvbiBpbml0KCkge1xuICAgIC8vIERPIFNPTUVUSElOR1xufVxuXG4vKlxuICogbGlzdGVuIGV2ZW50LCBvbmNlIGhhdmUgYmVlbiBsb2FkZWQgdGhlIGZpbGVzIENTU1xuICogKi9cbmlmICghaXNDU1NNaWNyb0xvYWRlZCgpKSB7XG4gICAgY3NzTWFpbi5hZGRFdmVudExpc3RlbmVyKCdsb2FkJywgX2ludGVybmFsQ1NTSW5pdCk7XG4gICAgLy8gTWFrZSBzdXJlIG1pY3Jvc2l0ZSBnZXRzIHZpc2libGUgYWZ0ZXIgMyBzZWNzXG4gICAgc2V0VGltZW91dChfaW50ZXJuYWxDU1NJbml0LCAzMDAwKTtcbn0gZWxzZSBpZiAoaXNDU1NNaWNyb0xvYWRlZCgpKSB7XG4gICAgc2V0VGltZW91dChfaW50ZXJuYWxDU1NJbml0LCAxMDApO1xufVxuXG5cbi8qXG4gKiBsaXN0ZW4gZXZlbnQsIG9uY2UgaGF2ZSBiZWVuIGxvYWRlZCB0aGUgZmlsZXMgSlNcbiAqICovXG5pZiAod2luZG93LnZmZXMpIHtcbiAgICBzZXRUaW1lb3V0KF9pbnRlcm5hbEpTSW5pdCwgMTAwKVxufSBlbHNlIHtcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCd2ZmVzOmZyYW1ld29ya1JlYWR5JywgX2ludGVybmFsSlNJbml0KTtcbn1cblxuY29uc3QgZXggPSB7XG4gICAgaXNEZXNrdG9wLFxuICAgIGlzVGFibGV0LFxuICAgIGlzTW9iaWxlLFxuICAgIG1pY3Jvc2l0ZUlkOiBNSUNST1NJVEVfSUQsXG4gICAgbWljcm9zaXRlUGF0aDogUEFUSF9NSUNST1NJVEUsXG4gICAgaW5pdDogaW5pdCxcbiAgICBjc3NMb2FkZWQ6IGZhbHNlLFxuICAgIG9uU3R5bGVzUmVhZHk6ICgpID0+IG51bGwsXG4gICAgb25GcmFtZXdvcmtSZWFkeTogKCkgPT4gbnVsbFxufTtcblxuZXhwb3J0IGRlZmF1bHQgZXg7XG4iXSwic291cmNlUm9vdCI6IiJ9